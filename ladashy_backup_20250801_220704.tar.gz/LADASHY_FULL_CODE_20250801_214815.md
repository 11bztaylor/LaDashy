# LaDashy Complete Code Extraction
Generated: Fri Aug  1 21:48:15 CDT 2025

=== EXTRACTING BACKEND CODE ===
## File: backend/api.py
```
"""
LaDashy REST API - Complete Implementation
Backend service with all features from the desktop version
"""
from flask import Flask, request, jsonify, send_file, send_from_directory
from flask_cors import CORS
import sys
import os
import json
import threading
import tempfile
import zipfile
from pathlib import Path
from datetime import datetime

# Add parent directories to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'shared'))

# Import all our modules
from homelab_wizard.core.scanner import NetworkScanner
from homelab_wizard.generators.documentation_generator import DocumentationGenerator
from homelab_wizard.collectors.manager import CollectorManager
from homelab_wizard.services.definitions import get_all_services

app = Flask(__name__)
CORS(app)

# Global storage
app.discovered_services = {}
app.service_configs = {}
app.collected_data = {}
app.scan_status = {"scanning": False, "progress": "", "error": None}

# Load saved configs if they exist
config_file = os.path.expanduser("~/.ladashy/service_configs.json")
if os.path.exists(config_file):
    with open(config_file, 'r') as f:
        app.service_configs = json.load(f)

from flask import send_from_directory
import os

# Add route for serving icons

@app.route('/icons/<path:filename>')
def serve_icon(filename):
    icons_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'icons')
    return send_from_directory(icons_dir, filename)

@app.route('/')
def index():
    """Redirect to frontend"""
    return send_from_directory('../frontend', 'index.html')

@app.route('/api/health')
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy", 
        "version": "2.0.0",
        "features": ["scan", "collect", "generate", "export"]
    })

@app.route('/api/scan', methods=['POST'])
def scan_network():
    """Start network scan"""
    if app.scan_status["scanning"]:
        return jsonify({"error": "Scan already in progress"}), 400
    
    data = request.json
    networks = data.get('networks', ['192.168.1.0/24'])
    
    def scan_worker():
        app.scan_status["scanning"] = True
        app.scan_status["error"] = None
        scanner = NetworkScanner()
        
        try:
            # Add networks
            for network in networks:
                scanner.add_network(network)
            
            # Progress callback
            def progress_callback(msg):
                app.scan_status["progress"] = msg
            
            # Scan
            app.discovered_services = scanner.discover_all_services(progress_callback)
            app.scan_status["progress"] = "Scan complete!"
            
        except Exception as e:
            app.scan_status["error"] = str(e)
        finally:
            app.scan_status["scanning"] = False
    
    thread = threading.Thread(target=scan_worker, daemon=True)
    thread.start()
    
    return jsonify({"status": "Scan started", "networks": networks})

@app.route('/api/scan/status')
def get_scan_status():
    """Get scan status"""
    total_services = sum(len(h.get('services', [])) for h in app.discovered_services.values())
    
    return jsonify({
        "scanning": app.scan_status["scanning"],
        "progress": app.scan_status["progress"],
        "error": app.scan_status["error"],
        "hosts_found": len(app.discovered_services),
        "services_found": total_services
    })

@app.route('/api/services')
def get_services():
    """Get discovered services"""
    return jsonify(app.discovered_services)

@app.route('/api/services/<service_name>/<host>/config', methods=['GET', 'POST'])
def service_config(service_name, host):
    """Get or update service configuration"""
    service_key = f"{service_name}_{host}"
    
    if request.method == 'GET':
        return jsonify(app.service_configs.get(service_key, {}))
    else:
        config = request.json
        app.service_configs[service_key] = config
        
        # Save to file
        os.makedirs(os.path.dirname(config_file), exist_ok=True)
        with open(config_file, 'w') as f:
            json.dump(app.service_configs, f, indent=2)
        
        # Try to collect data
        manager = CollectorManager()
        service_info = next(
            (s for h in app.discovered_services.values() 
             for s in h.get('services', []) 
             if s['name'] == service_name and h.get('ip') == host),
            None
        )
        
        if service_info:
            collector = manager.get_collector(service_name, config)  # Don't lowercase - manager handles it
            if collector:
                port = service_info['ports'][0] if service_info.get('ports') else 8080
                
                if collector.test_connection(host, port, config):
                    basic = collector.collect_basic_info(host, port, config)
                    detailed = collector.collect_detailed_info(host, port, config)
                    
                    app.collected_data[service_key] = {
                        **basic,
                        **detailed,
                        'last_updated': datetime.now().isoformat()
                    }
                    
                    return jsonify({
                        "status": "Configuration saved and data collected",
                        "data": app.collected_data[service_key]
                    })
        
        return jsonify({"status": "Configuration saved"})

@app.route('/api/services/<service_name>/<host>/test', methods=['POST'])
def test_service(service_name, host):
    """Test service connection"""
    try:
        config = request.json or {}
        
        # Ensure we have required fields
        if 'host' not in config:
            config['host'] = host
        
        # Get port from config or use service default
        if 'port' not in config:
            # Try to find port from discovered services
            port = None
            for h_ip, h_info in app.discovered_services.items():
                if h_ip == host:
                    for svc in h_info.get('services', []):
                        if svc['name'].lower() == service_name.lower():
                            port = svc['ports'][0] if svc.get('ports') else None
                            break
            
            # If not found in discovered, use service defaults
            if port is None:
                from homelab_wizard.services.definitions import SERVICES
                service_def = SERVICES.get(service_name.lower(), {})
                port = service_def.get('default_port', 8080)
            
            config['port'] = port
        
        # Create collector manager and get collector WITH CONFIG
        manager = CollectorManager()
        app.logger.info(f"Looking for collector: {service_name.lower()}")
        app.logger.info(f"Available collectors: {list(manager.collectors.keys())}")
        collector = manager.get_collector(service_name, config)  # Don't lowercase - manager handles it  # FIXED: Added config parameter
        
        if not collector:
            return jsonify({
                "status": "error",
                "message": f"No collector available for service: {service_name}"
            }), 404
        
        # Test the connection
        # test_connection() takes no arguments - the collector already has the config
        success = collector.test_connection()
        
        if success:
            return jsonify({
                "status": "success", 
                "message": "Connection successful!"
            })
        else:
            return jsonify({
                "status": "failed", 
                "message": "Could not connect to service. Please check your settings."
            }), 400
            
    except Exception as e:
        app.logger.error(f"Error testing service {service_name}: {str(e)}")
        return jsonify({
            "status": "error",
            "message": f"Error testing connection: {str(e)}"
        }), 500

def get_service_definitions():
    """Get all service definitions"""
    return jsonify(get_all_services())

@app.route('/api/generate', methods=['POST'])
def generate_documentation():
    """Generate documentation"""
    data = request.json
    options = data.get('options', {})
    
    # Create temporary directory
    with tempfile.TemporaryDirectory() as temp_dir:
        try:
            # Generate documentation
            generator = DocumentationGenerator(temp_dir)
            results = generator.generate_all(
                app.discovered_services,
                app.service_configs,
                app.collected_data
            )
            
            # Export additional formats
            if options.get('json', True):
                generator.export_to_json(
                    app.discovered_services,
                    app.service_configs,
                    app.collected_data
                )
            
            if options.get('html', True):
                generator.export_to_html_dashboard(
                    app.discovered_services,
                    app.service_configs
                )
            
            # Create zip file
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            zip_filename = f"ladashy_docs_{timestamp}.zip"
            zip_path = Path(temp_dir) / zip_filename
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(temp_dir):
                    for file in files:
                        if file != zip_filename:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, temp_dir)
                            zipf.write(file_path, arcname)
            
            return send_file(
                zip_path,
                as_attachment=True,
                download_name=zip_filename,
                mimetype='application/zip'
            )
            
        except Exception as e:
            return jsonify({"error": str(e)}), 500

@app.route('/api/state/save', methods=['POST'])
def save_state():
    """Save current state"""
    state = {
        'discovered_services': app.discovered_services,
        'service_configs': app.service_configs,
        'collected_data': app.collected_data,
        'timestamp': datetime.now().isoformat()
    }
    
    state_file = os.path.expanduser("~/.ladashy/state_backup.json")
    os.makedirs(os.path.dirname(state_file), exist_ok=True)
    
    with open(state_file, 'w') as f:
        json.dump(state, f, indent=2)
    
    return jsonify({"status": "State saved", "file": state_file})

@app.route('/api/state/load', methods=['POST'])
def load_state():
    """Load saved state"""
    state_file = os.path.expanduser("~/.ladashy/state_backup.json")
    
    if os.path.exists(state_file):
        with open(state_file, 'r') as f:
            state = json.load(f)
        
        app.discovered_services = state.get('discovered_services', {})
        app.service_configs = state.get('service_configs', {})
        app.collected_data = state.get('collected_data', {})
        
        return jsonify({
            "status": "State loaded",
            "timestamp": state.get('timestamp'),
            "services": sum(len(h.get('services', [])) for h in app.discovered_services.values())
        })
    else:
        return jsonify({"error": "No saved state found"}), 404

if __name__ == '__main__':
    print("\n" + "="*50)
    print("🚀 LaDashy API Server Starting...")
    print("="*50)
    print(f"📡 API URL: http://localhost:5000/api/")
    print(f"🌐 Web UI: http://localhost:8080/")
    print("="*50 + "\n")
    
    app.run(host='0.0.0.0', port=5000, debug=False)
```


=== EXTRACTING FRONTEND CODE ===
## File: frontend/index.html
```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LaDashy - Homelab Documentation Generator</title>
    <style>
        /* Reset and Variables */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        :root {
            --bg-primary: #1a1a1a;
            --bg-secondary: #2d2d2d;
            --bg-tertiary: #3d3d3d;
            --text-primary: #e0e0e0;
            --text-secondary: #b0b0b0;
            --accent-primary: #4ecdc4;
            --accent-secondary: #45b7d1;
            --accent-success: #96ceb4;
            --accent-warning: #ffd93d;
            --accent-error: #ff6b6b;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: var(--bg-secondary);
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            color: var(--accent-primary);
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header-actions {
            display: flex;
            gap: 10px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: var(--bg-secondary);
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            color: var(--accent-success);
            margin-bottom: 10px;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .stat-card .value {
            font-size: 2.5em;
            font-weight: bold;
            color: var(--accent-primary);
        }
        
        .controls {
            background: var(--bg-secondary);
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
        }
        
        .btn {
            background: var(--accent-primary);
            color: var(--bg-primary);
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            font-size: 1em;
            margin-right: 10px;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn:hover {
            background: var(--accent-secondary);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(78, 205, 196, 0.3);
        }
        
        .btn:disabled {
            background: #555;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .btn-secondary {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }
        
        .btn-secondary:hover {
            background: #4d4d4d;
        }
        
        .services {
            background: var(--bg-secondary);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            margin-bottom: 30px;
        }
        
        .service-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .service-card {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 8px;
            transition: all 0.3s;
            border: 1px solid transparent;
            position: relative;
        }
        
        .service-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.4);
            border-color: var(--accent-primary);
        }
        
        .service-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }
        
        .service-name {
            color: var(--accent-primary);
            font-weight: bold;
            font-size: 1.2em;
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .service-icon {
            font-size: 1.5em;
        }
        
        .service-info {
            font-size: 0.9em;
            color: var(--text-secondary);
            line-height: 1.8;
        }
        
        .service-status {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.9em;
        }
        
        .status-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
        }
        
        .status-configured { background: var(--accent-success); }
        .status-discovered { background: var(--accent-warning); }
        .status-error { background: var(--accent-error); }
        
        .service-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        
        .btn-small {
            padding: 6px 12px;
            font-size: 0.85em;
        }
        
        .progress {
            background: var(--bg-secondary);
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
        }
        
        .progress.active { display: block; }
        
        .progress-text {
            margin-bottom: 15px;
            font-size: 1.1em;
        }
        
        .progress-bar {
            background: var(--bg-tertiary);
            height: 30px;
            border-radius: 15px;
            overflow: hidden;
            position: relative;
        }
        
        .progress-fill {
            background: linear-gradient(90deg, var(--accent-primary), var(--accent-secondary));
            height: 100%;
            width: 0%;
            transition: width 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(
                90deg,
                transparent,
                rgba(255, 255, 255, 0.3),
                transparent
            );
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .option {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px;
            background: var(--bg-tertiary);
            border-radius: 5px;
            transition: background 0.2s;
        }
        
        .option:hover {
            background: #4d4d4d;
        }
        
        .option input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
            accent-color: var(--accent-primary);
        }
        
        .option label {
            cursor: pointer;
            flex: 1;
        }
        
        .network-input {
            background: var(--bg-tertiary);
            border: 1px solid #555;
            color: var(--text-primary);
            padding: 12px;
            border-radius: 5px;
            width: 100%;
            margin-bottom: 15px;
            font-size: 1em;
        }
        
        .network-input:focus {
            outline: none;
            border-color: var(--accent-primary);
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            overflow-y: auto;
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: var(--bg-secondary);
            padding: 30px;
            border-radius: 10px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .modal-header h2 {
            color: var(--accent-primary);
        }
        
        .close-btn {
            background: none;
            border: none;
            color: var(--text-primary);
            font-size: 1.5em;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 5px;
            transition: background 0.2s;
        }
        
        .close-btn:hover {
            background: var(--bg-tertiary);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-secondary);
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            background: var(--bg-tertiary);
            border: 1px solid #555;
            color: var(--text-primary);
            border-radius: 5px;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--accent-primary);
        }
        
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--bg-secondary);
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            display: none;
            align-items: center;
            gap: 10px;
            z-index: 2000;
        }
        
        .toast.show {
            display: flex;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .toast.success {
            border-left: 4px solid var(--accent-success);
        }
        
        .toast.error {
            border-left: 4px solid var(--accent-error);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-secondary);
        }
        
        .empty-state h3 {
            color: var(--text-primary);
            margin-bottom: 10px;
        }
        
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid var(--bg-tertiary);
        }
        
        .tab {
            padding: 10px 20px;
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            font-size: 1em;
            transition: all 0.3s;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
        }
        
        .tab:hover {
            color: var(--text-primary);
        }
        
        .tab.active {
            color: var(--accent-primary);
            border-bottom-color: var(--accent-primary);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }

        /* New styles for manual configuration */
        .manual-add-section {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .service-selector {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 10px;
            margin-top: 15px;
            max-height: 300px;
            overflow-y: auto;
            padding: 10px;
            background: var(--bg-secondary);
            border-radius: 5px;
        }

        .service-option {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px;
            background: var(--bg-tertiary);
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.2s;
            border: 2px solid transparent;
        }

        .service-option:hover {
            background: #4d4d4d;
            border-color: var(--accent-primary);
        }

        .service-option.selected {
            background: var(--accent-primary);
            color: var(--bg-primary);
            border-color: var(--accent-primary);
        }

        .service-icon-img {
            width: 24px;
            height: 24px;
            object-fit: contain;
            vertical-align: middle;
        }
        
        .service-option .service-icon-img {
            width: 20px;
            height: 20px;
        }
        
        /* Theme toggle button */
        .theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--bg-secondary);
            border: none;
            padding: 10px;
            border-radius: 50%;
            cursor: pointer;
            color: var(--text-primary);
            font-size: 1.2em;
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .theme-toggle:hover {
            background: var(--bg-tertiary);
            transform: scale(1.1);
        }
        
        /* Light theme */
        body.light-theme {
            --bg-primary: #f5f5f5;
            --bg-secondary: #ffffff;
            --bg-tertiary: #e0e0e0;
            --text-primary: #333333;
            --text-secondary: #666666;
            --accent-primary: #2196F3;
            --accent-secondary: #1976D2;
        }
    </style>
</head>
<body>
    <button class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">
        <span id="theme-icon">🌙</span>
    </button>
    
    <div class="container">
        <div class="header">
            <div>
                <h1>🏠 LaDashy</h1>
                <p>Homelab Documentation Generator</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-secondary" onclick="saveState()">💾 Save State</button>
                <button class="btn btn-secondary" onclick="loadState()">📂 Load State</button>
            </div>
        </div>

        <div class="stats">
            <div class="stat-card">
                <h3>Hosts Found</h3>
                <div class="value" id="stat-hosts">0</div>
            </div>
            <div class="stat-card">
                <h3>Services</h3>
                <div class="value" id="stat-services">0</div>
            </div>
            <div class="stat-card">
                <h3>Configured</h3>
                <div class="value" id="stat-configured">0</div>
            </div>
            <div class="stat-card">
                <h3>Data Collected</h3>
                <div class="value" id="stat-collected">0</div>
            </div>
        </div>

        <div class="controls">
            <h2>Service Discovery & Configuration</h2>
            
            <!-- Manual Add Section -->
            <div class="manual-add-section">
                <h3>➕ Manually Add Services</h3>
                <p style="color: var(--text-secondary); margin: 10px 0;">
                    Don't want to scan? Add your services manually:
                </p>
                <button class="btn" onclick="showManualAdd()">
                    <span>➕</span> Add Service Manually
                </button>
            </div>
            
            <!-- Network Scanner Section -->
            <div style="margin: 20px 0;">
                <h3>🔍 Network Scanner</h3>
                <p style="color: var(--text-secondary); margin: 10px 0;">
                    Or automatically discover services on your network:
                </p>
                <label>Network Range (comma-separated for multiple):</label>
                <input type="text" id="network-range" class="network-input" 
                       value="192.168.1.0/24" placeholder="192.168.1.0/24, 10.0.0.0/24">
                <button class="btn" id="btn-scan" onclick="startScan()">
                    <span>🔍</span> Scan Network
                </button>
            </div>
            
            <button class="btn" id="btn-generate" onclick="showGenerateOptions()" disabled>
                <span>📄</span> Generate Documentation
            </button>
        </div>

        <div class="progress" id="progress">
            <div class="progress-text" id="progress-text">Initializing scan...</div>
            <div class="progress-bar">
                <div class="progress-fill" id="progress-fill"></div>
            </div>
        </div>

        <div class="services" id="services" style="display: none;">
            <div class="tabs">
                <button class="tab active" onclick="switchTab('discovered')">All Services</button>
                <button class="tab" onclick="switchTab('configured')">Configured Services</button>
                <button class="tab" onclick="switchTab('collected')">Collected Data</button>
            </div>
            
            <div class="tab-content active" id="tab-discovered">
                <div class="service-grid" id="service-grid"></div>
            </div>
            
            <div class="tab-content" id="tab-configured">
                <div class="service-grid" id="configured-grid"></div>
            </div>
            
            <div class="tab-content" id="tab-collected">
                <div class="service-grid" id="collected-grid"></div>
            </div>
        </div>

        <!-- Service Configuration Modal -->
        <div class="modal" id="config-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 id="config-title">Configure Service</h2>
                    <button class="close-btn" onclick="closeConfigModal()">×</button>
                </div>
                <div id="config-form"></div>
            </div>
        </div>

        <!-- Manual Add Service Modal -->
        <div class="modal" id="manual-add-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Add Service Manually</h2>
                    <button class="close-btn" onclick="closeManualAddModal()">×</button>
                </div>
                <div>
                    <div class="form-group">
                        <label>Service Type</label>
                        <input type="text" id="manual-search" placeholder="Search services..." 
                               oninput="filterServices()" class="network-input">
                        <div class="service-selector" id="service-selector"></div>
                    </div>
                    <div class="form-group">
                        <label>Host/IP Address</label>
                        <input type="text" id="manual-host" placeholder="192.168.1.100 or hostname">
                    </div>
                    <div class="form-group">
                        <label>Port</label>
                        <input type="text" id="manual-port" placeholder="Default port will be used">
                        <small style="color: var(--text-secondary); display: block; margin-top: 5px;">
                            Default port will be filled when you select a service
                        </small>
                    </div>
                    <div class="form-group">
                        <label>API Key (if required)</label>
                        <input type="text" id="manual-api-key" placeholder="API key for service">
                    </div>
                    <div style="margin-top: 20px; display: flex; gap: 10px;">
                        <button class="btn" onclick="addManualService()">
                            <span>➕</span> Add Service
                        </button>
                        <button class="btn btn-secondary" onclick="closeManualAddModal()">Cancel</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Generate Options Modal -->
        <div class="modal" id="generate-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Documentation Options</h2>
                    <button class="close-btn" onclick="hideGenerateOptions()">×</button>
                </div>
                <div class="options">
                    <div class="option">
                        <input type="checkbox" id="opt-network" checked>
                        <label for="opt-network">Network Topology Diagram</label>
                    </div>
                    <div class="option">
                        <input type="checkbox" id="opt-dependencies" checked>
                        <label for="opt-dependencies">Service Dependencies</label>
                    </div>
                    <div class="option">
                        <input type="checkbox" id="opt-docker" checked>
                        <label for="opt-docker">Docker Compose Files</label>
                    </div>
                    <div class="option">
                        <input type="checkbox" id="opt-security" checked>
                        <label for="opt-security">Security Audit</label>
                    </div>
                    <div class="option">
                        <input type="checkbox" id="opt-json" checked>
                        <label for="opt-json">JSON Export</label>
                    </div>
                    <div class="option">
                        <input type="checkbox" id="opt-html" checked>
                        <label for="opt-html">HTML Dashboard</label>
                    </div>
                </div>
                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <button class="btn" onclick="generateDocs()">
                        <span>🚀</span> Generate & Download
                    </button>
                    <button class="btn btn-secondary" onclick="hideGenerateOptions()">Cancel</button>
                </div>
            </div>
        </div>

        <!-- Toast Notification -->
        <div class="toast" id="toast">
            <span id="toast-message"></span>
        </div>
    </div>

    <script src="service-icons.js"></script>
    <script>
        // Global variables and configuration
        const API_URL = 'http://localhost:5000/api';
        let scanInterval = null;
        let services = {};
        let configs = {};
        let collectedData = {};
        let currentService = null;
        let selectedServiceType = null;

        // All available services
        const AVAILABLE_SERVICES = [
            // Media
            { name: 'Plex', category: 'Media', defaultPort: 32400 },
            { name: 'Jellyfin', category: 'Media', defaultPort: 8096 },
            { name: 'Emby', category: 'Media', defaultPort: 8096 },
            { name: 'Radarr', category: 'Media', defaultPort: 7878 },
            { name: 'Sonarr', category: 'Media', defaultPort: 8989 },
            { name: 'Prowlarr', category: 'Media', defaultPort: 9696 },
            { name: 'Bazarr', category: 'Media', defaultPort: 6767 },
            { name: 'Lidarr', category: 'Media', defaultPort: 8686 },
            { name: 'Readarr', category: 'Media', defaultPort: 8787 },
            { name: 'Overseerr', category: 'Media', defaultPort: 5055 },
            { name: 'Ombi', category: 'Media', defaultPort: 3579 },
            { name: 'Tautulli', category: 'Media', defaultPort: 8181 },
            
            // Network
            { name: 'Nginx Proxy Manager', category: 'Network', defaultPort: 81 },
            { name: 'Traefik', category: 'Network', defaultPort: 8080 },
            { name: 'Pi-hole', category: 'Network', defaultPort: 80 },
            { name: 'AdGuard Home', category: 'Network', defaultPort: 3000 },
            
            // Management
            { name: 'Portainer', category: 'Management', defaultPort: 9000 },
            { name: 'Cockpit', category: 'Management', defaultPort: 9090 },
            
            // Monitoring
            { name: 'Grafana', category: 'Monitoring', defaultPort: 3000 },
            { name: 'Prometheus', category: 'Monitoring', defaultPort: 9090 },
            { name: 'InfluxDB', category: 'Monitoring', defaultPort: 8086 },
            { name: 'Uptime Kuma', category: 'Monitoring', defaultPort: 3001 },
            
            // Home Automation
            { name: 'Home Assistant', category: 'Home Automation', defaultPort: 8123 },
            { name: 'Node-RED', category: 'Home Automation', defaultPort: 1880 },
            
            // Storage
            { name: 'Nextcloud', category: 'Storage', defaultPort: 443 },
            { name: 'MinIO', category: 'Storage', defaultPort: 9000 },
            { name: 'Syncthing', category: 'Storage', defaultPort: 8384 },
        ];

        // Helper function to get service icon
        function getServiceIcon(serviceName) {
            // This function should be defined in service-icons.js
            // For now, return a default emoji if not found
            if (typeof window.getServiceIcon === 'function') {
                return window.getServiceIcon(serviceName);
            }
            return '📦'; // Default icon
        }

        // Manual Service Management Functions
        function showManualAdd() {
            document.getElementById('manual-add-modal').classList.add('active');
            populateServiceSelector();
        }

        function closeManualAddModal() {
            document.getElementById('manual-add-modal').classList.remove('active');
            selectedServiceType = null;
            // Clear form
            document.getElementById('manual-host').value = '';
            document.getElementById('manual-port').value = '';
            document.getElementById('manual-api-key').value = '';
            document.getElementById('manual-search').value = '';
        }

        function populateServiceSelector() {
            const selector = document.getElementById('service-selector');
            selector.innerHTML = '';
            
            AVAILABLE_SERVICES.forEach(service => {
                const option = document.createElement('div');
                option.className = 'service-option';
                option.onclick = () => selectServiceType(service);
                option.innerHTML = `
                    <span class="service-icon">${getServiceIcon(service.name)}</span>
                    <span>${service.name}</span>
                `;
                selector.appendChild(option);
            });
        }

        function filterServices() {
            const search = document.getElementById('manual-search').value.toLowerCase();
            const options = document.querySelectorAll('.service-option');
            
            options.forEach(option => {
                const text = option.textContent.toLowerCase();
                option.style.display = text.includes(search) ? 'flex' : 'none';
            });
        }

        function selectServiceType(service) {
            selectedServiceType = service;
            
            // Update UI
            document.querySelectorAll('.service-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            event.target.closest('.service-option').classList.add('selected');
            
            // Set default port
            const portInput = document.getElementById('manual-port');
            portInput.value = service.defaultPort;
            portInput.placeholder = `Default: ${service.defaultPort}`;
        }

        async function addManualService() {
            if (!selectedServiceType) {
                showToast('Please select a service type', 'error');
                return;
            }
            
            const host = document.getElementById('manual-host').value.trim();
            if (!host) {
                showToast('Please enter a host/IP address', 'error');
                return;
            }
            
            const portValue = document.getElementById('manual-port').value || selectedServiceType.defaultPort;
            const port = parseInt(portValue);
            
            // Validate port
            if (isNaN(port) || port < 1 || port > 65535) {
                showToast('Please enter a valid port number (1-65535)', 'error');
                return;
            }
            
            // Add to services
            if (!services[host]) {
                services[host] = {
                    hostname: host,
                    services: []
                };
            }
            
            // Check if service already exists
            const existingService = services[host].services.find(s => 
                s.name === selectedServiceType.name && s.ports.includes(port)
            );
            
            if (existingService) {
                showToast('This service is already added', 'error');
                return;
            }
            
            // Save config if API key provided
            const apiKey = document.getElementById('manual-api-key').value;
            const key = `${selectedServiceType.name}_${host}`;
            
            if (apiKey) {
                configs[key] = {
                    host: host,
                    port: port,
                    api_key: apiKey
                };
            }
            
            // Add service
            services[host].services.push({
                name: selectedServiceType.name,
                ports: [port],
                confidence: 1.0,
                device_type: 'manual',
                configured: !!apiKey
            });
            
            // Update UI
            updateServiceGrid();
            closeManualAddModal();
            showToast(`Added ${selectedServiceType.name} on ${host}:${port}`, 'success');
            
            // Enable generate button
            document.getElementById('btn-generate').disabled = false;
            document.getElementById('services').style.display = 'block';
            
            // Update stats
            updateStats();
        }

        // Network Scanning Functions
        async function startScan() {
            const networks = document.getElementById('network-range').value
                .split(',')
                .map(n => n.trim())
                .filter(n => n);
            
            if (networks.length === 0) {
                showToast('Please enter at least one network range', 'error');
                return;
            }
            
            document.getElementById('btn-scan').disabled = true;
            document.getElementById('progress').classList.add('active');
            
            try {
                console.log("Starting scan with networks:", networks);
                
                const response = await fetch(`${API_URL}/scan`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ networks })
                });
                
                const data = await response.json();
                console.log("Scan response:", data);
                
                if (response.ok) {
                    showToast('Network scan started!', 'success');
                    scanInterval = setInterval(checkScanStatus, 1000);
                } else {
                    throw new Error(data.error || 'Failed to start scan');
                }
            } catch (error) {
                console.error("Scan error:", error);
                showToast('Failed to start scan: ' + error.message, 'error');
                document.getElementById('btn-scan').disabled = false;
                document.getElementById('progress').classList.remove('active');
            }
        }

        async function checkScanStatus() {
            try {
                const response = await fetch(`${API_URL}/scan/status`);
                const status = await response.json();
                
                document.getElementById('progress-text').textContent = status.progress || 'Scanning...';
                document.getElementById('stat-hosts').textContent = status.hosts_found || 0;
                document.getElementById('stat-services').textContent = status.services_found || 0;
                
                // Update progress bar
                if (status.progress && status.progress.includes('complete')) {
                    document.getElementById('progress-fill').style.width = '100%';
                } else {
                    // Estimate progress
                    const progress = Math.min((status.services_found || 0) * 10, 90);
                    document.getElementById('progress-fill').style.width = progress + '%';
                }
                
                if (!status.scanning) {
                    clearInterval(scanInterval);
                    document.getElementById('btn-scan').disabled = false;
                    document.getElementById('progress').classList.remove('active');
                    
                    if (status.error) {
                        showToast('Scan error: ' + status.error, 'error');
                    } else {
                        showToast('Scan complete!', 'success');
                        await loadServices();
                    }
                }
            } catch (error) {
                console.error('Status check error:', error);
            }
        }

        async function loadServices() {
            try {
                const response = await fetch(`${API_URL}/services`);
                const scannedServices = await response.json();
                
                // Merge with existing manually added services
                for (const [ip, hostInfo] of Object.entries(scannedServices)) {
                    if (services[ip]) {
                        // Merge services, avoiding duplicates
                        const existingNames = services[ip].services.map(s => s.name);
                        for (const service of hostInfo.services) {
                            if (!existingNames.includes(service.name)) {
                                services[ip].services.push(service);
                            }
                        }
                    } else {
                        services[ip] = hostInfo;
                    }
                }
                
                updateServiceGrid();
                document.getElementById('services').style.display = 'block';
                document.getElementById('btn-generate').disabled = Object.keys(services).length === 0;
                updateStats();
                
            } catch (error) {
                showToast('Failed to load services: ' + error.message, 'error');
            }
        }

        // Service Configuration Functions
        async function configureService(serviceName, host) {
            currentService = { name: serviceName, host: host };
            const key = `${serviceName}_${host}`;
            
            document.getElementById('config-title').textContent = `Configure ${serviceName}`;
            
            // Get existing config
            const config = configs[key] || {};
            
            // Build form based on service type
            let formHtml = '';
            
            // Common fields
            formHtml += `
                <div class="form-group">
                    <label>Host</label>
                    <input type="text" id="config-host" value="${host}" readonly>
                </div>
            `;
            
            // Service-specific fields
            const serviceNameLower = serviceName.toLowerCase();
            
            if (serviceNameLower.includes('plex')) {
                formHtml += `
                    <div class="form-group">
                        <label>Plex Token</label>
                        <input type="text" id="config-token" placeholder="Your Plex token" 
                               value="${config.token || ''}">
                    </div>
                `;
            } else if (['radarr', 'sonarr', 'prowlarr', 'bazarr', 'lidarr', 'readarr'].some(s => serviceNameLower.includes(s))) {
                formHtml += `
                    <div class="form-group">
                        <label>API Key</label>
                        <input type="text" id="config-api_key" placeholder="API key from settings" 
                               value="${config.api_key || ''}">
                    </div>
                `;
            } else if (serviceNameLower.includes('jellyfin')) {
                formHtml += `
                    <div class="form-group">
                        <label>API Key</label>
                        <input type="text" id="config-api_key" placeholder="Jellyfin API key" 
                               value="${config.api_key || ''}">
                    </div>
                `;
            } else if (serviceNameLower.includes('portainer')) {
                formHtml += `
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" id="config-username" placeholder="Admin username" 
                               value="${config.username || ''}">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" id="config-password" placeholder="Admin password" 
                               value="${config.password || ''}">
                    </div>
                `;
            } else {
                // Generic config
                formHtml += `
                    <div class="form-group">
                        <label>Username (if required)</label>
                        <input type="text" id="config-username" placeholder="Username" 
                               value="${config.username || ''}">
                    </div>
                    <div class="form-group">
                        <label>Password (if required)</label>
                        <input type="password" id="config-password" placeholder="Password" 
                               value="${config.password || ''}">
                    </div>
                    <div class="form-group">
                        <label>API Key (if required)</label>
                        <input type="text" id="config-api_key" placeholder="API key" 
                               value="${config.api_key || ''}">
                    </div>
                `;
            }
            
            formHtml += `
                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <button class="btn" onclick="saveConfig()">💾 Save</button>
                    <button class="btn btn-secondary" onclick="closeConfigModal()">Cancel</button>
                </div>
            `;
            
            document.getElementById('config-form').innerHTML = formHtml;
            document.getElementById('config-modal').classList.add('active');
        }

        async function saveConfig() {
            if (!currentService) return;
            
            const key = `${currentService.name}_${currentService.host}`;
            const config = { host: currentService.host };
            
            // Collect form values
            const fields = ['token', 'api_key', 'username', 'password'];
            for (const field of fields) {
                const input = document.getElementById(`config-${field}`);
                if (input && input.value) {
                    config[field] = input.value;
                }
            }
            
            try {
                const response = await fetch(
                    `${API_URL}/services/${currentService.name}/${currentService.host}/config`,
                    {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(config)
                    }
                );
                
                const result = await response.json();
                
                if (response.ok) {
                    configs[key] = config;
                    
                    // Mark service as configured
                    for (const [ip, hostInfo] of Object.entries(services)) {
                        if (ip === currentService.host) {
                            const service = hostInfo.services.find(s => s.name === currentService.name);
                            if (service) {
                                service.configured = true;
                            }
                        }
                    }
                    
                    if (result.data) {
                        collectedData[key] = result.data;
                        showToast('Configuration saved and data collected!', 'success');
                    } else {
                        showToast('Configuration saved!', 'success');
                    }
                    
                    closeConfigModal();
                    updateServiceGrid();
                    updateStats();
                } else {
                    throw new Error(result.error || 'Failed to save configuration');
                }
            } catch (error) {
                showToast('Error: ' + error.message, 'error');
            }
        }

        async function testService(serviceName, host) {
            const key = `${serviceName}_${host}`;
            const config = configs[key];
            
            if (!config) {
                showToast('Please configure the service first', 'error');
                return;
            }
            
            try {
                const response = await fetch(
                    `${API_URL}/services/${serviceName}/${host}/test`,
                    {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(config)
                    }
                );
                
                const result = await response.json();
                
                if (response.ok && result.success) {
                    showToast(`✅ ${result.message || 'Connection successful!'}`, 'success');
                } else {
                    showToast(`❌ ${result.message || 'Connection failed'}`, 'error');
                }
            } catch (error) {
                showToast('Connection test failed: ' + error.message, 'error');
            }
        }

        function closeConfigModal() {
            document.getElementById('config-modal').classList.remove('active');
            currentService = null;
        }

        // Documentation Generation Functions
        function showGenerateOptions() {
            document.getElementById('generate-modal').classList.add('active');
        }

        function hideGenerateOptions() {
            document.getElementById('generate-modal').classList.remove('active');
        }

        async function generateDocs() {
            const options = {
                network_topology: document.getElementById('opt-network').checked,
                service_dependencies: document.getElementById('opt-dependencies').checked,
                docker_compose: document.getElementById('opt-docker').checked,
                security_audit: document.getElementById('opt-security').checked,
                json: document.getElementById('opt-json').checked,
                html: document.getElementById('opt-html').checked
            };
            
            showToast('Generating documentation...', 'success');
            
            try {
                const response = await fetch(`${API_URL}/dashboard/generate`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        options,
                        services: services,
                        configs: configs
                    })
                });
                
                if (response.ok) {
                    const blob = await response.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `ladashy_docs_${new Date().toISOString().slice(0, 10)}.zip`;
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                    
                    hideGenerateOptions();
                    showToast('Documentation generated and downloaded!', 'success');
                } else {
                    throw new Error('Generation failed');
                }
            } catch (error) {
                showToast('Failed to generate documentation: ' + error.message, 'error');
            }
        }

        // State Management Functions
        async function saveState() {
            try {
                const response = await fetch(`${API_URL}/state/save`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        services: services,
                        configs: configs,
                        collectedData: collectedData
                    })
                });
                
                const result = await response.json();
                showToast('State saved successfully!', 'success');
            } catch (error) {
                showToast('Failed to save state: ' + error.message, 'error');
            }
        }

        async function loadState() {
            try {
                const response = await fetch(`${API_URL}/state/load`);
                
                if (response.ok) {
                    const result = await response.json();
                    
                    if (result.services) services = result.services;
                    if (result.configs) configs = result.configs;
                    if (result.collectedData) collectedData = result.collectedData;
                    
                    updateServiceGrid();
                    updateStats();
                    document.getElementById('services').style.display = 'block';
                    document.getElementById('btn-generate').disabled = Object.keys(services).length === 0;
                    
                    showToast(`State loaded! ${Object.keys(services).length} hosts found`, 'success');
                } else {
                    showToast('No saved state found', 'error');
                }
            } catch (error) {
                showToast('Failed to load state: ' + error.message, 'error');
            }
        }

        // UI Update Functions
        function updateServiceGrid() {
            const grid = document.getElementById('service-grid');
            grid.innerHTML = '';
            
            if (Object.keys(services).length === 0) {
                grid.innerHTML = `
                    <div class="empty-state" style="grid-column: 1/-1;">
                        <h3>No services yet</h3>
                        <p>Add services manually or run a network scan</p>
                    </div>
                `;
                return;
            }
            
            for (const [ip, hostInfo] of Object.entries(services)) {
                for (const service of hostInfo.services || []) {
                    const key = `${service.name}_${ip}`;
                    const isConfigured = !!configs[key] || service.configured;
                    const hasData = !!collectedData[key];
                    
                    const card = document.createElement('div');
                    card.className = 'service-card';
                    card.innerHTML = `
                        <div class="service-header">
                            <div>
                                <div class="service-name">
                                    <span class="service-icon" data-service="${service.name}">${getServiceIcon(service.name)}</span>
                                    ${service.name}
                                </div>
                                <div class="service-status">
                                    <span class="status-indicator status-${isConfigured ? 'configured' : 'discovered'}"></span>
                                    <span>${isConfigured ? 'Configured' : (service.device_type === 'manual' ? 'Added Manually' : 'Discovered')}</span>
                                </div>
                            </div>
                        </div>
                        <div class="service-info">
                            <strong>Host:</strong> ${hostInfo.hostname} (${ip})<br>
                            <strong>Ports:</strong> ${service.ports.join(', ')}<br>
                            ${service.device_type !== 'manual' ? `<strong>Confidence:</strong> ${(service.confidence * 100).toFixed(0)}%<br>` : ''}
                            <strong>Type:</strong> ${service.device_type || 'Unknown'}
                        </div>
                        <div class="service-actions">
                            <button class="btn btn-small" onclick="configureService('${service.name}', '${ip}')">
                                ${isConfigured ? '⚙️ Edit Config' : '➕ Configure'}
                            </button>
                            ${isConfigured ? `
                                <button class="btn btn-small btn-secondary" onclick="testService('${service.name}', '${ip}')">
                                    🔗 Test
                                </button>
                            ` : ''}
                        </div>
                    `;
                    grid.appendChild(card);
                }
            }
        }

        function switchTab(tab) {
            // Update tab buttons
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            
            // Update tab content
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            document.getElementById(`tab-${tab}`).classList.add('active');
            
            // Update content based on tab
            if (tab === 'configured') {
                updateConfiguredGrid();
            } else if (tab === 'collected') {
                updateCollectedGrid();
            }
        }

        function updateConfiguredGrid() {
            const grid = document.getElementById('configured-grid');
            grid.innerHTML = '';
            
            let hasConfigured = false;
            
            for (const [ip, hostInfo] of Object.entries(services)) {
                for (const service of hostInfo.services || []) {
                    const key = `${service.name}_${ip}`;
                    if (configs[key] || service.configured) {
                        hasConfigured = true;
                        const card = createServiceCard(service, hostInfo, ip, true);
                        grid.appendChild(card);
                    }
                }
            }
            
            if (!hasConfigured) {
                grid.innerHTML = `
                    <div class="empty-state" style="grid-column: 1/-1;">
                        <h3>No configured services yet</h3>
                        <p>Configure services from the All Services tab</p>
                    </div>
                `;
            }
        }

        function updateCollectedGrid() {
            const grid = document.getElementById('collected-grid');
            grid.innerHTML = '';
            
            if (Object.keys(collectedData).length === 0) {
                grid.innerHTML = `
                    <div class="empty-state" style="grid-column: 1/-1;">
                        <h3>No data collected yet</h3>
                        <p>Configure services to collect data</p>
                    </div>
                `;
                return;
            }
            
            for (const [key, data] of Object.entries(collectedData)) {
                const [serviceName, ...hostParts] = key.split('_');
                const host = hostParts.join('_');
                
                const card = document.createElement('div');
                card.className = 'service-card';
                card.innerHTML = `
                    <div class="service-header">
                        <div>
                            <div class="service-name">
                                <span class="service-icon" data-service="${serviceName}">${getServiceIcon(serviceName)}</span>
                                ${serviceName}
                            </div>
                            <div class="service-status">
                                <span class="status-indicator status-configured"></span>
                                <span>Data Available</span>
                            </div>
                        </div>
                    </div>
                    <div class="service-info">
                        <strong>Host:</strong> ${host}<br>
                        <strong>Last Updated:</strong> ${data.last_updated ? new Date(data.last_updated).toLocaleString() : 'Unknown'}<br>
                        ${formatCollectedData(data)}
                    </div>
                `;
                grid.appendChild(card);
            }
        }

        function formatCollectedData(data) {
            let html = '';
            
            // Show key data points
            if (data.version) html += `<strong>Version:</strong> ${data.version}<br>`;
            if (data.libraries) html += `<strong>Libraries:</strong> ${data.libraries.length}<br>`;
            if (data.movies) html += `<strong>Movies:</strong> ${data.movies}<br>`;
            if (data.series) html += `<strong>Series:</strong> ${data.series}<br>`;
            if (data.domains_blocked) html += `<strong>Domains Blocked:</strong> ${data.domains_blocked.toLocaleString()}<br>`;
            if (data.dns_queries_today) html += `<strong>DNS Queries Today:</strong> ${data.dns_queries_today.toLocaleString()}<br>`;
            
            return html;
        }

        function createServiceCard(service, hostInfo, ip, showData = false) {
            const key = `${service.name}_${ip}`;
            const isConfigured = !!configs[key] || service.configured;
            const hasData = !!collectedData[key];
            
            const card = document.createElement('div');
            card.className = 'service-card';
            card.innerHTML = `
                <div class="service-header">
                    <div>
                        <div class="service-name">
                            <span class="service-icon" data-service="${service.name}">${getServiceIcon(service.name)}</span>
                            ${service.name}
                        </div>
                        <div class="service-status">
                            <span class="status-indicator status-${isConfigured ? 'configured' : 'discovered'}"></span>
                            <span>${isConfigured ? 'Configured' : (service.device_type === 'manual' ? 'Added Manually' : 'Discovered')}</span>
                        </div>
                    </div>
                </div>
                <div class="service-info">
                    <strong>Host:</strong> ${hostInfo.hostname} (${ip})<br>
                    <strong>Ports:</strong> ${service.ports.join(', ')}<br>
                    ${service.device_type !== 'manual' ? `<strong>Confidence:</strong> ${(service.confidence * 100).toFixed(0)}%<br>` : ''}
                    <strong>Type:</strong> ${service.device_type || 'Unknown'}
                    ${showData && hasData ? '<br>' + formatCollectedData(collectedData[key]) : ''}
                </div>
                <div class="service-actions">
                    <button class="btn btn-small" onclick="configureService('${service.name}', '${ip}')">
                        ${isConfigured ? '⚙️ Edit Config' : '➕ Configure'}
                    </button>
                    ${isConfigured ? `
                        <button class="btn btn-small btn-secondary" onclick="testService('${service.name}', '${ip}')">
                            🔗 Test
                        </button>
                    ` : ''}
                </div>
            `;
            return card;
        }

        function updateStats() {
            let totalServices = 0;
            let configuredCount = 0;
            
            for (const [ip, hostInfo] of Object.entries(services)) {
                for (const service of hostInfo.services || []) {
                    totalServices++;
                    const key = `${service.name}_${ip}`;
                    if (configs[key] || service.configured) configuredCount++;
                }
            }
            
            document.getElementById('stat-hosts').textContent = Object.keys(services).length;
            document.getElementById('stat-services').textContent = totalServices;
            document.getElementById('stat-configured').textContent = configuredCount;
            document.getElementById('stat-collected').textContent = Object.keys(collectedData).length;
        }

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toast.className = `toast ${type} show`;
            toastMessage.textContent = message;
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Theme handling
        function toggleTheme() {
            const body = document.body;
            const currentTheme = body.classList.contains('light-theme') ? 'light' : 'dark';
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            if (newTheme === 'light') {
                body.classList.add('light-theme');
                document.getElementById('theme-icon').textContent = '☀️';
            } else {
                body.classList.remove('light-theme');
                document.getElementById('theme-icon').textContent = '🌙';
            }
            
            localStorage.setItem('theme', newTheme);
            
            // Reload all service icons with new theme
            document.querySelectorAll('.service-icon').forEach(iconContainer => {
                const serviceName = iconContainer.getAttribute('data-service');
                if (serviceName) {
                    iconContainer.innerHTML = getServiceIcon(serviceName);
                }
            });
        }
        
        // Initialize theme on load
        function initTheme() {
            const savedTheme = localStorage.getItem('theme') || 'dark';
            if (savedTheme === 'light') {
                document.body.classList.add('light-theme');
                document.getElementById('theme-icon').textContent = '☀️';
            }
        }

        // Initialize on load
        window.addEventListener('load', () => {
            initTheme();
            loadServices();
            document.getElementById('services').style.display = 'block';
        });

        // Handle modal clicks
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('active');
            }
        });

        // Log function availability for debugging
        console.log('LaDashy initialized. Functions available:', {
            startScan: typeof startScan,
            showManualAdd: typeof showManualAdd,
            configureService: typeof configureService,
            testService: typeof testService,
            saveConfig: typeof saveConfig,
            closeConfigModal: typeof closeConfigModal,
            toggleTheme: typeof toggleTheme
        });
    </script>
</body>
</html>```

## File: frontend/service-icons.js
```
// Service icon mappings - using actual PNG icons
const SERVICE_ICON_MAP = {
    // Media Services
    'plex': 'plex',
    'jellyfin': 'jellyfin',
    'emby': 'emby',
    'kodi': 'kodi',
    'radarr': 'radarr',
    'sonarr': 'sonarr',
    'lidarr': 'lidarr',
    'readarr': 'readarr',
    'bazarr': 'bazarr',
    'prowlarr': 'prowlarr',
    'overseerr': 'overseerr',
    'ombi': 'ombi',
    'tautulli': 'tautulli',
    
    // Download Clients
    'qbittorrent': 'qbittorrent',
    'transmission': 'transmission',
    'sabnzbd': 'sabnzbd',
    'nzbget': 'nzbget',
    'deluge': 'deluge',
    
    // Network Services
    'nginx proxy manager': 'nginx-proxy-manager',
    'traefik': 'traefik',
    'caddy': 'caddy',
    'pi-hole': 'pihole',
    'adguard home': 'adguard-home',
    'wireguard': 'wireguard',
    'openvpn': 'openvpn',
    'tailscale': 'tailscale',
    
    // Monitoring
    'grafana': 'grafana',
    'prometheus': 'prometheus',
    'influxdb': 'influxdb',
    'uptime kuma': 'uptime-kuma',
    'netdata': 'netdata',
    'glances': 'glances',
    
    // Management
    'portainer': 'portainer',
    'yacht': 'yacht',
    'cockpit': 'cockpit',
    'webmin': 'webmin',
    
    // Home Automation
    'home assistant': 'home-assistant',
    'node-red': 'node-red',
    'mosquitto': 'mosquitto',
    'zigbee2mqtt': 'zigbee2mqtt',
    'esphome': 'esphome',
    
    // Storage & Backup
    'nextcloud': 'nextcloud',
    'syncthing': 'syncthing',
    'minio': 'minio',
    'duplicati': 'duplicati',
    'photoprism': 'photoprism',
    'immich': 'immich',
    
    // Default
    'default': 'dashboard'
};

// Theme detection
function getCurrentTheme() {
    // You can implement actual theme detection here
    // For now, let's use a CSS variable or localStorage
    return localStorage.getItem('theme') || 'dark';
}

function getServiceIcon(serviceName) {
    const normalized = serviceName.toLowerCase();
    const iconName = SERVICE_ICON_MAP[normalized] || SERVICE_ICON_MAP['default'];
    const theme = getCurrentTheme();
    
    // Return an img element instead of emoji
    const iconPath = `/icons/${iconName}_${theme}.png`;
    return `<img src="${iconPath}" alt="${serviceName}" class="service-icon-img" onerror="this.onerror=null; this.src='/icons/dashboard_${theme}.png';">`;
}

// For backward compatibility with emoji version
function getServiceIconEmoji(serviceName) {
    const SERVICE_EMOJI = {
        'plex': '🎬',
        'jellyfin': '🎭',
        'default': '🔧'
    };
    const normalized = serviceName.toLowerCase();
    return SERVICE_EMOJI[normalized] || SERVICE_EMOJI['default'];
}
```

## File: frontend/update-icons.js
```
// Temporary fix: Update all icon displays to show emoji when image fails
document.addEventListener('DOMContentLoaded', function() {
    // Override image error handling
    document.body.addEventListener('error', function(e) {
        if (e.target.tagName === 'IMG' && e.target.classList.contains('service-icon-img')) {
            // Get service name from alt attribute
            const serviceName = e.target.alt;
            const emoji = getServiceIconEmoji(serviceName);
            
            // Replace image with emoji
            const emojiSpan = document.createElement('span');
            emojiSpan.style.fontSize = '1.5em';
            emojiSpan.textContent = emoji;
            e.target.parentNode.replaceChild(emojiSpan, e.target);
        }
    }, true);
});
```


=== EXTRACTING COLLECTORS ===
## File: homelab_wizard/collectors/manager.py
```
"""
Data collection manager
"""
from typing import Dict, Any, Optional, Tuple
from .plex_collector import PlexCollector
from .radarr_collector import RadarrCollector
from .sonarr_collector import SonarrCollector
from .jellyfin_collector import JellyfinCollector
from .portainer_collector import PortainerCollector
from .pihole_collector import PiholeCollector
from .base_collector import BaseCollector

class CollectorManager:
    def __init__(self):
        self.collectors = {
            "Plex": PlexCollector,
            "Radarr": RadarrCollector,
            "Sonarr": SonarrCollector,
            "Jellyfin": JellyfinCollector,
            "Portainer": PortainerCollector,
            "Pi-hole": PiholeCollector,
        }
        
    def get_collector(self, service_name: str, config: Dict[str, str]) -> Optional[BaseCollector]:
        """Get appropriate collector for a service"""
        # Try exact match first
        collector_class = self.collectors.get(service_name)
        
        # If not found, try case-insensitive match
        if not collector_class:
            for key, value in self.collectors.items():
                if key.lower() == service_name.lower():
                    collector_class = value
                    break
        
        if collector_class:
            return collector_class(config)
        return None
        
    def test_service(self, service_name: str, config: Dict[str, str]) -> Tuple[bool, str]:
        """Test connection to a service"""
        collector = self.get_collector(service_name, config)
        if collector:
            return collector.test_connection()
        else:
            # Fallback to generic test
            from ..core.connection_tester import ConnectionTester
            tester = ConnectionTester()
            return tester.test_connection(service_name, config)
            
    def collect_service_data(self, service_name: str, config: Dict[str, str]) -> Dict[str, Any]:
        """Collect all data from a service"""
        collector = self.get_collector(service_name, config)
        if collector:
            return collector.collect_all()
        else:
            return {
                "status": "error",
                "error": f"No collector available for {service_name}"
            }
```

## File: homelab_wizard/collectors/base_collector.py
```
"""
Base collector class for all services
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Tuple
import logging

class BaseCollector(ABC):
    def __init__(self, config: Dict[str, str]):
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)
        
    @abstractmethod
    def test_connection(self) -> Tuple[bool, str]:
        """Test if connection to service is working"""
        pass
        
    @abstractmethod
    def collect_basic_info(self) -> Dict[str, Any]:
        """Collect basic service information"""
        pass
        
    @abstractmethod
    def collect_detailed_info(self) -> Dict[str, Any]:
        """Collect detailed service information for documentation"""
        pass
        
    def collect_all(self) -> Dict[str, Any]:
        """Collect all available information"""
        try:
            basic = self.collect_basic_info()
            detailed = self.collect_detailed_info()
            return {
                "basic": basic,
                "detailed": detailed,
                "status": "success"
            }
        except Exception as e:
            self.logger.error(f"Collection failed: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
```

## File: homelab_wizard/collectors/plex_collector.py
```
"""
Plex data collector
"""
import requests
from typing import Dict, Any, Tuple
from .base_collector import BaseCollector

class PlexCollector(BaseCollector):
    def __init__(self, config: Dict[str, str]):
        super().__init__(config)
        self.base_url = f"http://{config['host']}:{config.get('port', '32400')}"
        self.headers = {}
        if 'token' in config:
            self.headers['X-Plex-Token'] = config['token']
    
    def test_connection(self) -> Tuple[bool, str]:
        """Test Plex connection"""
        try:
            response = requests.get(
                f"{self.base_url}/identity",
                headers=self.headers,
                timeout=5
            )
            if response.status_code == 200:
                return True, "Connected to Plex"
            elif response.status_code == 401:
                return False, "Authentication failed - check token"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
    
    def collect_basic_info(self) -> Dict[str, Any]:
        """Collect basic Plex information"""
        try:
            # Server identity
            identity = requests.get(
                f"{self.base_url}/identity",
                headers=self.headers
            ).json()
            
            # Server preferences
            prefs = requests.get(
                f"{self.base_url}/:/prefs",
                headers=self.headers
            ).json()
            
            return {
                "server_name": identity.get("MediaContainer", {}).get("machineIdentifier"),
                "version": identity.get("MediaContainer", {}).get("version"),
                "platform": identity.get("MediaContainer", {}).get("platform"),
                "friendly_name": prefs.get("MediaContainer", {}).get("FriendlyName"),
            }
        except Exception as e:
            return {"error": str(e)}
    
    def collect_detailed_info(self) -> Dict[str, Any]:
        """Collect detailed Plex information"""
        try:
            detailed = {}
            
            # Libraries
            libraries_resp = requests.get(
                f"{self.base_url}/library/sections",
                headers=self.headers
            )
            if libraries_resp.status_code == 200:
                libraries_data = libraries_resp.json()
                detailed['libraries'] = []
                
                for lib in libraries_data.get("MediaContainer", {}).get("Directory", []):
                    lib_info = {
                        "title": lib.get("title"),
                        "type": lib.get("type"),
                        "key": lib.get("key"),
                        "locations": lib.get("Location", [])
                    }
                    
                    # Get library stats
                    stats_resp = requests.get(
                        f"{self.base_url}/library/sections/{lib['key']}/all",
                        headers=self.headers,
                        params={"X-Plex-Container-Size": 0}
                    )
                    if stats_resp.status_code == 200:
                        stats_data = stats_resp.json()
                        lib_info['item_count'] = stats_data.get("MediaContainer", {}).get("totalSize", 0)
                    
                    detailed['libraries'].append(lib_info)
            
            # Active sessions
            sessions_resp = requests.get(
                f"{self.base_url}/status/sessions",
                headers=self.headers
            )
            if sessions_resp.status_code == 200:
                sessions_data = sessions_resp.json()
                detailed['active_sessions'] = sessions_data.get("MediaContainer", {}).get("size", 0)
            
            return detailed
        except Exception as e:
            return {"error": str(e)}
```

## File: homelab_wizard/collectors/radarr_collector.py
```
"""
Radarr data collector
"""
import requests
from typing import Dict, Any, Tuple
from .base_collector import BaseCollector

class RadarrCollector(BaseCollector):
    def __init__(self, config: Dict[str, str]):
        super().__init__(config)
        self.base_url = f"http://{config['host']}:{config.get('port', '7878')}"
        if config.get('base_url'):
            self.base_url += config['base_url']
        self.headers = {}
        if 'api_key' in config:
            self.headers['X-Api-Key'] = config['api_key']
    
    def test_connection(self) -> Tuple[bool, str]:
        """Test Radarr connection"""
        try:
            response = requests.get(
                f"{self.base_url}/api/v3/system/status",
                headers=self.headers,
                timeout=5
            )
            if response.status_code == 200:
                return True, "Connected to Radarr"
            elif response.status_code == 401:
                return False, "Authentication failed - check API key"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
    
    def collect_basic_info(self) -> Dict[str, Any]:
        """Collect basic Radarr information"""
        try:
            # System status
            status = requests.get(
                f"{self.base_url}/api/v3/system/status",
                headers=self.headers
            ).json()
            
            return {
                "version": status.get("version"),
                "build_time": status.get("buildTime"),
                "start_time": status.get("startTime"),
                "app_name": status.get("appName"),
            }
        except Exception as e:
            return {"error": str(e)}
    
    def collect_detailed_info(self) -> Dict[str, Any]:
        """Collect detailed Radarr information"""
        try:
            detailed = {}
            
            # Movie statistics
            movies = requests.get(
                f"{self.base_url}/api/v3/movie",
                headers=self.headers
            ).json()
            
            detailed['total_movies'] = len(movies)
            detailed['monitored_movies'] = sum(1 for m in movies if m.get('monitored'))
            detailed['downloaded_movies'] = sum(1 for m in movies if m.get('hasFile'))
            
            # Root folders
            root_folders = requests.get(
                f"{self.base_url}/api/v3/rootfolder",
                headers=self.headers
            ).json()
            
            detailed['root_folders'] = [
                {
                    "path": rf.get("path"),
                    "free_space": rf.get("freeSpace"),
                    "total_space": rf.get("totalSpace")
                }
                for rf in root_folders
            ]
            
            # Queue info
            queue = requests.get(
                f"{self.base_url}/api/v3/queue",
                headers=self.headers
            ).json()
            
            detailed['queue_count'] = queue.get('totalRecords', 0)
            
            return detailed
        except Exception as e:
            return {"error": str(e)}
```

## File: homelab_wizard/collectors/sonarr_collector.py
```
"""
Sonarr data collector
"""
import requests
from typing import Dict, Any, Tuple
from .base_collector import BaseCollector

class SonarrCollector(BaseCollector):
    def __init__(self, config: Dict[str, str]):
        super().__init__(config)
        self.base_url = f"http://{config['host']}:{config.get('port', '8989')}"
        if config.get('base_url'):
            self.base_url += config['base_url']
        self.headers = {}
        if 'api_key' in config:
            self.headers['X-Api-Key'] = config['api_key']
    
    def test_connection(self) -> Tuple[bool, str]:
        """Test Sonarr connection"""
        try:
            response = requests.get(
                f"{self.base_url}/api/v3/system/status",
                headers=self.headers,
                timeout=5
            )
            if response.status_code == 200:
                return True, "Connected to Sonarr"
            elif response.status_code == 401:
                return False, "Authentication failed - check API key"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
    
    def collect_basic_info(self) -> Dict[str, Any]:
        """Collect basic Sonarr information"""
        try:
            status = requests.get(
                f"{self.base_url}/api/v3/system/status",
                headers=self.headers
            ).json()
            
            return {
                "version": status.get("version"),
                "build_time": status.get("buildTime"),
                "app_name": status.get("appName", "Sonarr"),
            }
        except Exception as e:
            return {"error": str(e)}
    
    def collect_detailed_info(self) -> Dict[str, Any]:
        """Collect detailed Sonarr information"""
        try:
            detailed = {}
            
            # Series statistics
            series = requests.get(
                f"{self.base_url}/api/v3/series",
                headers=self.headers
            ).json()
            
            detailed['total_series'] = len(series)
            detailed['monitored_series'] = sum(1 for s in series if s.get('monitored'))
            
            # Episode statistics
            total_episodes = 0
            downloaded_episodes = 0
            
            for show in series:
                stats = show.get('statistics', {})
                total_episodes += stats.get('totalEpisodeCount', 0)
                downloaded_episodes += stats.get('episodeFileCount', 0)
                
            detailed['total_episodes'] = total_episodes
            detailed['downloaded_episodes'] = downloaded_episodes
            
            # Queue info
            queue = requests.get(
                f"{self.base_url}/api/v3/queue",
                headers=self.headers
            ).json()
            
            detailed['queue_count'] = queue.get('totalRecords', 0)
            
            # Root folders
            root_folders = requests.get(
                f"{self.base_url}/api/v3/rootfolder",
                headers=self.headers
            ).json()
            
            detailed['root_folders'] = [
                {
                    "path": rf.get("path"),
                    "freeSpace": rf.get("freeSpace"),
                    "totalSpace": rf.get("totalSpace")
                }
                for rf in root_folders
            ]
            
            return detailed
        except Exception as e:
            return {"error": str(e)}
```

## File: homelab_wizard/collectors/jellyfin_collector.py
```
"""Collector for Jellyfin media server"""
import requests
from typing import Dict, Any, Optional
from .base_collector import BaseCollector

class JellyfinCollector(BaseCollector):
    """Collector for Jellyfin media server"""
    
    def __init__(self):
        super().__init__()
        self.name = "Jellyfin"
        self.default_port = 8096
        
    def test_connection(self, host: str, port: int, config: Dict[str, Any]) -> bool:
        """Test connection to Jellyfin"""
        try:
            # Jellyfin public endpoint
            response = self.session.get(
                f"http://{host}:{port}/System/Info/Public",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            self.logger.error(f"Jellyfin connection failed: {e}")
            return False
    
    def collect_basic_info(self, host: str, port: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """Collect basic Jellyfin information"""
        try:
            # Get public system info
            response = self.session.get(
                f"http://{host}:{port}/System/Info/Public",
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'server_name': data.get('ServerName', 'Unknown'),
                    'version': data.get('Version', 'Unknown'),
                    'operating_system': data.get('OperatingSystem', 'Unknown'),
                    'id': data.get('Id', 'Unknown')
                }
        except Exception as e:
            self.logger.error(f"Failed to collect Jellyfin info: {e}")
        
        return {}
    
    def collect_detailed_info(self, host: str, port: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """Collect detailed Jellyfin information (requires API key)"""
        api_key = config.get('api_key')
        if not api_key:
            return {'error': 'API key required for detailed information'}
        
        try:
            headers = {'X-Emby-Token': api_key}
            
            # Get library information
            libraries_response = self.session.get(
                f"http://{host}:{port}/Library/VirtualFolders",
                headers=headers,
                timeout=self.timeout
            )
            
            detailed_info = {}
            
            if libraries_response.status_code == 200:
                libraries = libraries_response.json()
                detailed_info['libraries'] = []
                for lib in libraries:
                    detailed_info['libraries'].append({
                        'name': lib.get('Name'),
                        'path': lib.get('Locations', ['Unknown'])[0] if lib.get('Locations') else 'Unknown',
                        'type': lib.get('CollectionType', 'Unknown')
                    })
                detailed_info['total_libraries'] = len(libraries)
            
            return detailed_info
            
        except Exception as e:
            self.logger.error(f"Failed to collect detailed Jellyfin info: {e}")
            return {'error': str(e)}
```

## File: homelab_wizard/collectors/portainer_collector.py
```
"""Collector for Portainer Docker management"""
import requests
from typing import Dict, Any, Optional
from .base_collector import BaseCollector

class PortainerCollector(BaseCollector):
    """Collector for Portainer Docker management"""
    
    def __init__(self):
        super().__init__()
        self.name = "Portainer"
        self.default_port = 9000
        
    def test_connection(self, host: str, port: int, config: Dict[str, Any]) -> bool:
        """Test connection to Portainer"""
        try:
            response = self.session.get(
                f"http://{host}:{port}/api/status",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            self.logger.error(f"Portainer connection failed: {e}")
            return False
    
    def collect_basic_info(self, host: str, port: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """Collect basic Portainer information"""
        try:
            response = self.session.get(
                f"http://{host}:{port}/api/status",
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'version': data.get('Version', 'Unknown'),
                    'instance_id': data.get('InstanceID', 'Unknown')
                }
        except Exception as e:
            self.logger.error(f"Failed to collect Portainer info: {e}")
        
        return {}
    
    def collect_detailed_info(self, host: str, port: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """Collect detailed Portainer information (requires authentication)"""
        username = config.get('username')
        password = config.get('password')
        
        if not username or not password:
            return {'error': 'Username and password required for detailed information'}
        
        try:
            # Authenticate
            auth_response = self.session.post(
                f"http://{host}:{port}/api/auth",
                json={'Username': username, 'Password': password},
                timeout=self.timeout
            )
            
            if auth_response.status_code != 200:
                return {'error': 'Authentication failed'}
            
            token = auth_response.json().get('jwt')
            headers = {'Authorization': f'Bearer {token}'}
            
            # Get endpoints
            endpoints_response = self.session.get(
                f"http://{host}:{port}/api/endpoints",
                headers=headers,
                timeout=self.timeout
            )
            
            detailed_info = {}
            
            if endpoints_response.status_code == 200:
                endpoints = endpoints_response.json()
                detailed_info['total_endpoints'] = len(endpoints)
                detailed_info['endpoints'] = []
                
                for endpoint in endpoints[:3]:  # Limit to first 3 endpoints
                    endpoint_info = {
                        'name': endpoint.get('Name'),
                        'type': endpoint.get('Type'),
                        'status': endpoint.get('Status')
                    }
                    detailed_info['endpoints'].append(endpoint_info)
            
            return detailed_info
            
        except Exception as e:
            self.logger.error(f"Failed to collect detailed Portainer info: {e}")
            return {'error': str(e)}
```

## File: homelab_wizard/collectors/pihole_collector.py
```
"""Collector for Pi-hole DNS ad blocker"""
import requests
from typing import Dict, Any, Optional
from .base_collector import BaseCollector

class PiholeCollector(BaseCollector):
    """Collector for Pi-hole DNS ad blocker"""
    
    def __init__(self):
        super().__init__()
        self.name = "Pi-hole"
        self.default_port = 80
        
    def test_connection(self, host: str, port: int, config: Dict[str, Any]) -> bool:
        """Test connection to Pi-hole"""
        try:
            response = self.session.get(
                f"http://{host}:{port}/admin/api.php?status",
                timeout=self.timeout
            )
            return response.status_code == 200
        except Exception as e:
            self.logger.error(f"Pi-hole connection failed: {e}")
            return False
    
    def collect_basic_info(self, host: str, port: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """Collect basic Pi-hole information"""
        try:
            # Get status
            status_response = self.session.get(
                f"http://{host}:{port}/admin/api.php?status",
                timeout=self.timeout
            )
            
            # Get version
            version_response = self.session.get(
                f"http://{host}:{port}/admin/api.php?version",
                timeout=self.timeout
            )
            
            basic_info = {}
            
            if status_response.status_code == 200:
                status_data = status_response.json()
                basic_info['status'] = status_data.get('status', 'Unknown')
            
            if version_response.status_code == 200:
                version_data = version_response.json()
                basic_info['core_version'] = version_data.get('core_current', 'Unknown')
                basic_info['web_version'] = version_data.get('web_current', 'Unknown')
                basic_info['ftl_version'] = version_data.get('FTL_current', 'Unknown')
            
            return basic_info
            
        except Exception as e:
            self.logger.error(f"Failed to collect Pi-hole info: {e}")
        
        return {}
    
    def collect_detailed_info(self, host: str, port: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """Collect detailed Pi-hole statistics"""
        try:
            # Get summary stats (doesn't require auth for basic stats)
            summary_response = self.session.get(
                f"http://{host}:{port}/admin/api.php?summary",
                timeout=self.timeout
            )
            
            if summary_response.status_code == 200:
                data = summary_response.json()
                return {
                    'domains_blocked': data.get('domains_being_blocked', 0),
                    'dns_queries_today': data.get('dns_queries_today', 0),
                    'ads_blocked_today': data.get('ads_blocked_today', 0),
                    'ads_percentage_today': data.get('ads_percentage_today', 0),
                    'unique_domains': data.get('unique_domains', 0),
                    'queries_forwarded': data.get('queries_forwarded', 0),
                    'queries_cached': data.get('queries_cached', 0),
                    'clients_ever_seen': data.get('clients_ever_seen', 0),
                    'unique_clients': data.get('unique_clients', 0),
                    'status': data.get('status', 'Unknown')
                }
            
        except Exception as e:
            self.logger.error(f"Failed to collect detailed Pi-hole info: {e}")
            
        return {}
```


=== EXTRACTING CORE MODULES ===
## File: homelab_wizard/core/scanner.py
```
import urllib3
import warnings

import urllib3
import warnings

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

"""
Network scanner for service discovery
"""
import socket
import subprocess
import platform
import ipaddress
import threading
from typing import List, Dict, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from .service_detector import ServiceDetector

class NetworkScanner:
    def __init__(self):
        self.networks = []  # No default network - use what user provides
        self.discovered_hosts = []
        self.scan_timeout = 1
        self.max_threads = 50
        
    def add_network(self, network: str) -> bool:
        """Add a network to scan list"""
        try:
            # Validate network format
            ipaddress.ip_network(network)
            if network not in self.networks:
                self.networks.append(network)
            return True
        except ValueError:
            return False
    
    def remove_network(self, network: str):
        """Remove a network from scan list"""
        if network in self.networks:
            self.networks.remove(network)
    
    def get_networks(self) -> List[str]:
        """Get list of networks to scan"""
        return self.networks.copy()
    
    def scan_networks(self, progress_callback=None) -> Dict[str, str]:
        """Scan all configured networks for active hosts"""
        all_hosts = {}
        
        for network in self.networks:
            if progress_callback:
                progress_callback(f"Scanning network: {network}")
            
            hosts = self._scan_network(network, progress_callback)
            all_hosts.update(hosts)
            
        return all_hosts
    
    def _scan_network(self, network: str, progress_callback=None) -> Dict[str, str]:
        """Scan a specific network"""
        hosts = {}
        
        try:
            net = ipaddress.ip_network(network)
            total_hosts = sum(1 for _ in net.hosts())
            
            if progress_callback:
                progress_callback(f"Scanning {total_hosts} hosts in {network}")
            
            # Use thread pool for parallel scanning
            with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                # Submit all ping tasks
                future_to_ip = {
                    executor.submit(self._check_host, str(ip)): str(ip) 
                    for ip in net.hosts()
                }
                
                # Process results as they complete
                completed = 0
                for future in as_completed(future_to_ip):
                    ip = future_to_ip[future]
                    completed += 1
                    
                    if progress_callback and completed % 10 == 0:
                        progress_callback(f"Progress: {completed}/{total_hosts} hosts")
                    
                    try:
                        hostname = future.result()
                        if hostname:
                            hosts[ip] = hostname
                            if progress_callback:
                                progress_callback(f"Found: {ip} ({hostname})")
                    except Exception as e:
                        pass
                        
        except ValueError as e:
            if progress_callback:
                progress_callback(f"Invalid network: {network}")
                
        return hosts
    
    def _check_host(self, ip: str) -> str:
        """Check if host is alive and get hostname"""
        if self._ping_host(ip):
            # Try to get hostname
            try:
                hostname = socket.gethostbyaddr(ip)[0]
                return hostname
            except:
                return "Unknown"
        return None
    
    def _ping_host(self, ip: str) -> bool:
        """Check if host is reachable"""
        param = "-n" if platform.system().lower() == "windows" else "-c"
        command = ["ping", param, "1", "-W", str(self.scan_timeout), ip]
        
        try:
            result = subprocess.run(
                command, 
                capture_output=True, 
                timeout=self.scan_timeout + 0.5
            )
            return result.returncode == 0
        except:
            return False
    
    def scan_host_services(self, host: str, progress_callback=None) -> List[Dict]:
        """Scan a specific host for services"""
        from ..services.definitions import get_all_services
        
        discovered_services = []
        all_services = get_all_services()
        
        if progress_callback:
            progress_callback(f"Scanning services on {host}")
        
        # Check each service
        for service in all_services:
            if progress_callback:
                progress_callback(f"Checking {service['name']} on {host}")
            
            # Check if service ports are open
            open_ports = self.scan_ports(host, service["ports"])
            if open_ports:
                discovered_services.append({
                    "name": service["name"],
                    "host": host,
                    "ports": open_ports,
                    "description": service["description"]
                })
                
        return discovered_services
    
    def scan_ports(self, host: str, ports: List[int]) -> List[int]:
        """Scan specific ports on a host"""
        open_ports = []
        
        for port in ports:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            
            try:
                result = sock.connect_ex((host, port))
                if result == 0:
                    open_ports.append(port)
            except:
                pass
            finally:
                sock.close()
                
        return open_ports
    
    def discover_all_services(self, progress_callback=None) -> Dict[str, List[Dict]]:
        """Discover all services on all networks with comprehensive port scanning"""
        all_services = {}
        
        # First, find all hosts
        hosts = self.scan_networks(progress_callback)
        
        # Import what we need
        from ..services.definitions import get_all_services
        all_service_definitions = get_all_services()
        
        # Then scan each host for services
        for ip, hostname in hosts.items():
            if progress_callback:
                progress_callback(f"Deep scanning {ip} ({hostname})")
            
            # Comprehensive port list
            ports_to_check = [
                # Web services
                80, 443, 8080, 8443, 8081, 8090, 8000, 3000, 5000, 5001,
                # Media services
                32400,  # Plex
                8096,   # Jellyfin/Emby
                7878,   # Radarr
                8989,   # Sonarr
                9696,   # Prowlarr
                6767,   # Bazarr
                8686,   # Lidarr
                8787,   # Readarr
                8181,   # Tautulli
                5055,   # Overseerr
                3579,   # Ombi
                # Download clients
                8112,   # Deluge
                9091,   # Transmission
                6881,   # qBittorrent
                # Management
                9000,   # Portainer
                9090,   # Cockpit/Prometheus
                81,     # Nginx Proxy Manager
                # Network services
                53, 22, 21, 445,
                # Databases
                3306, 5432, 27017, 6379,
            ]
            
            # Find open ports
            open_ports = []
            for port in ports_to_check:
                if self._is_port_open(ip, port):
                    open_ports.append(port)
                    if progress_callback:
                        progress_callback(f"Found open port {port} on {ip}")
            
            if not open_ports:
                continue
            
            # Try smart detection if available
            detected_services = {}
            try:
                from .service_detector import ServiceDetector
                detector = ServiceDetector()
                
                for port in open_ports:
                    service_name, confidence = detector.identify_service(ip, port)
                    if service_name:
                        detected_services[port] = (service_name, confidence)
            except:
                pass
            
            # Match services based on ports
            found_services = []
            
            # Check each service definition
            for service_def in all_service_definitions:
                service_ports = service_def.get("ports", [])
                matched_ports = [p for p in service_ports if p in open_ports]
                
                if matched_ports:
                    # Calculate confidence
                    confidence = 0.6  # Base confidence from port match
                    
                    # Check if smart detection agrees
                    for port in matched_ports:
                        if port in detected_services:
                            detected_name, detected_conf = detected_services[port]
                            if service_def["name"].lower() in detected_name.lower():
                                confidence = max(confidence, detected_conf)
                    
                    found_services.append({
                        "name": service_def["name"],
                        "host": ip,
                        "ports": matched_ports,
                        "description": service_def.get("description", ""),
                        "confidence": confidence,
                        "device_type": "docker" if hostname == "Unknown" else "host"
                    })
            
            # Add any services detected but not in our definitions
            for port, (service_name, confidence) in detected_services.items():
                # Check if we already added this service
                already_added = any(
                    service_name.lower() in s["name"].lower() 
                    for s in found_services
                )
                if not already_added and confidence > 0.7:
                    found_services.append({
                        "name": service_name.replace('_', ' ').title(),
                        "host": ip,
                        "ports": [port],
                        "confidence": confidence,
                        "device_type": "detected"
                    })
            
            if found_services:
                all_services[ip] = {
                    "hostname": hostname,
                    "services": found_services
                }
        
        return all_services

    def _is_port_open(self, host: str, port: int) -> bool:
        """Quick check if port is open"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.2)  # Very fast timeout
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0

    ```

## File: homelab_wizard/core/service_detector.py
```
"""
Advanced service detection with multiple identification methods
"""
import socket
import requests
import json
from typing import Dict, List, Optional, Tuple

class ServiceDetector:
    def __init__(self):
        self.timeout = 2
        
    def identify_service(self, host: str, port: int) -> Tuple[str, float]:
        """
        Identify service on host:port
        Returns: (service_name, confidence_score)
        """
        # Try multiple detection methods
        methods = [
            self._check_http_response,
            self._check_banner,
            self._check_specific_endpoints,
        ]
        
        results = []
        for method in methods:
            try:
                service, confidence = method(host, port)
                if service:
                    results.append((service, confidence))
            except:
                pass
        
        # Return the highest confidence result
        if results:
            return max(results, key=lambda x: x[1])
        
        return None, 0
    
    def identify_router(self, host: str, open_ports: List[int]) -> Tuple[str, float]:
        """Identify if device is a router/gateway"""
        router_indicators = 0
        
        # Check if it has typical router ports
        if 53 in open_ports:  # DNS
            router_indicators += 1
        if any(p in open_ports for p in [80, 443]):  # Web interface
            router_indicators += 1
        if 22 in open_ports or 23 in open_ports:  # SSH/Telnet
            router_indicators += 1
        
        # Check if it's .1 address (common for gateways)
        if host.endswith('.1'):
            router_indicators += 2
        
        # Try to identify specific router types
        if router_indicators >= 2:
            # Check for UniFi
            try:
                # UniFi typically runs on 8443
                if 8443 in open_ports:
                    response = requests.get(f"https://{host}:8443", verify=False, timeout=2)
                    if 'unifi' in response.text.lower():
                        return 'unifi_gateway', 0.95
            except:
                pass
            
            # Check for pfSense
            try:
                if 443 in open_ports:
                    response = requests.get(f"https://{host}", verify=False, timeout=2)
                    if 'pfsense' in response.text.lower():
                        return 'pfsense', 0.95
            except:
                pass
            
            # Generic router
            if router_indicators >= 3:
                return 'router', 0.85
        
        return None, 0
    
    def is_docker_container(self, host: str, hostname: str) -> bool:
        """Check if host is likely a Docker container"""
        # Docker containers often have specific hostname patterns
        docker_patterns = [
            hostname.lower() == 'unknown',
            hostname.startswith('container'),
            len(hostname) == 12 and all(c in '0123456789abcdef' for c in hostname),  # Container ID
            '.docker' in hostname,
            '.local' not in hostname and '.' not in hostname,  # No domain
        ]
        
        # Check IP patterns (Docker default subnets)
        docker_subnets = ['172.16.', '172.17.', '172.18.', '172.19.', '172.20.', '172.21.']
        if any(host.startswith(subnet) for subnet in docker_subnets):
            return True
        
        return any(docker_patterns)
    
    def identify_service_smart(self, host: str, port: int, open_ports: List[int], hostname: str) -> Tuple[str, float]:
        """Smart service identification with context"""
        # First check if it's a router
        router_type, confidence = self.identify_router(host, open_ports)
        if router_type and confidence > 0.8:
            # Don't identify DNS on routers as Pi-hole
            if port == 53:
                return None, 0
            # Don't identify web interface as generic web server
            if port in [80, 443]:
                return router_type, confidence
        
        # Check if it's a Docker container
        is_container = self.is_docker_container(host, hostname)
        
        # If it's a container, boost confidence for container services
        base_service, base_confidence = self.identify_service(host, port)
        
        if is_container and base_service:
            # Boost confidence for services commonly run in Docker
            docker_services = ['plex', 'jellyfin', 'radarr', 'sonarr', 'prowlarr', 
                              'portainer', 'nginx', 'traefik', 'grafana', 'influxdb']
            if any(svc in base_service.lower() for svc in docker_services):
                base_confidence = min(base_confidence * 1.2, 0.99)
        
        return base_service, base_confidence
    
    def _check_http_response(self, host: str, port: int) -> Tuple[str, float]:
        """Check HTTP/HTTPS response headers and content"""
        protocols = ['http', 'https'] if port == 443 else ['http']
        
        for protocol in protocols:
            try:
                url = f"{protocol}://{host}:{port}"
                response = requests.get(url, timeout=self.timeout, verify=False, allow_redirects=True)
                
                # Check headers
                headers = response.headers
                content = response.text.lower()
                
                # Service-specific identifications
                checks = [
                    # Plex
                    ('plex', 0.9, [
                        lambda: 'plex' in headers.get('X-Plex-Protocol', '').lower(),
                        lambda: 'x-plex-version' in headers,
                        lambda: 'plex media server' in content,
                    ]),
                    
                    # Jellyfin
                    ('jellyfin', 0.9, [
                        lambda: 'jellyfin' in headers.get('Server', '').lower(),
                        lambda: 'jellyfin' in content,
                        lambda: '/web/index.html' in content and 'jellyfin' in content,
                    ]),
                    
                    # Radarr
                    ('radarr', 0.95, [
                        lambda: 'radarr' in content,
                        lambda: '<title>radarr</title>' in content,
                        lambda: port == 7878,
                    ]),
                    
                    # Sonarr
                    ('sonarr', 0.95, [
                        lambda: 'sonarr' in content,
                        lambda: '<title>sonarr</title>' in content,
                        lambda: port == 8989,
                    ]),
                    
                    # Prowlarr
                    ('prowlarr', 0.95, [
                        lambda: 'prowlarr' in content,
                        lambda: '<title>prowlarr</title>' in content,
                        lambda: port == 9696,
                    ]),
                    
                    # Pi-hole
                    ('pihole', 0.95, [
                        lambda: 'pi-hole' in content,
                        lambda: '/admin/api.php' in content,
                        lambda: 'x-pi-hole' in headers,
                    ]),
                    
                    # Portainer
                    ('portainer', 0.95, [
                        lambda: 'portainer' in content,
                        lambda: port == 9000,
                    ]),
                    
                    # UniFi Controller
                    ('unifi', 0.9, [
                        lambda: 'unifi' in content,
                        lambda: port == 8443,
                    ]),
                ]
                
                # Check each service
                for service_name, base_confidence, checks_list in checks:
                    matches = sum(1 for check in checks_list if self._safe_check(check))
                    if matches > 0:
                        confidence = base_confidence * (matches / len(checks_list))
                        return service_name, confidence
                        
            except Exception as e:
                pass
        
        return None, 0
    
    def _check_banner(self, host: str, port: int) -> Tuple[str, float]:
        """Check service banner"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            sock.connect((host, port))
            
            # For some services, we need to send data first
            if port in [80, 8080, 8096, 32400]:
                sock.send(b"GET / HTTP/1.0\r\n\r\n")
            
            banner = sock.recv(1024).decode('utf-8', errors='ignore').lower()
            sock.close()
            
            # Check banner content
            banner_checks = [
                ('plex', 0.8, ['plex media server']),
                ('ssh', 0.95, ['ssh-', 'openssh']),
                ('ftp', 0.9, ['ftp', '220 ']),
            ]
            
            for service, confidence, keywords in banner_checks:
                if any(keyword in banner for keyword in keywords):
                    return service, confidence
                    
        except:
            pass
            
        return None, 0
    
    def _check_specific_endpoints(self, host: str, port: int) -> Tuple[str, float]:
        """Check specific API endpoints"""
        endpoint_checks = [
            # Plex
            ('plex', '/identity', lambda r: 'machineidentifier' in r.text.lower(), 32400),
            
            # Radarr
            ('radarr', '/api/v3/config/ui', lambda r: True, 7878),
            
            # Sonarr  
            ('sonarr', '/api/v3/config/ui', lambda r: True, 8989),
            
            # Prowlarr
            ('prowlarr', '/api/v1/config/ui', lambda r: True, 9696),
        ]
        
        for service, endpoint, check_func, expected_port in endpoint_checks:
            if port == expected_port:
                try:
                    url = f"http://{host}:{port}{endpoint}"
                    response = requests.get(url, timeout=self.timeout)
                    if response.status_code == 200 and check_func(response):
                        return service, 0.95
                except:
                    pass
        
        return None, 0
    
    def _safe_check(self, check_func):
        """Safely execute a check function"""
        try:
            return check_func()
        except:
            return False
    
    def identify_printer(self, host: str) -> bool:
        """Check if a device is a printer"""
        printer_ports = [631, 9100, 515]  # IPP, RAW, LPR
        
        for port in printer_ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((host, port))
                sock.close()
                if result == 0:
                    return True
            except:
                pass
                
        return False
    
    def get_device_type(self, host: str, open_ports: List[int]) -> str:
        """Determine device type based on open ports"""
        # Check for printer
        if self.identify_printer(host):
            return "printer"
            
        # Router/Gateway signatures
        if all(p in open_ports for p in [53, 80]) and host.endswith('.1'):
            return "router"
            
        return "unknown"

    def identify_service_safe(self, host: str, port: int) -> Tuple[str, float]:
        """Safe wrapper for service identification"""
        try:
            return self.identify_service(host, port)
        except Exception as e:
            # Return none on any error
            return None, 0
```

## File: homelab_wizard/core/connection_tester.py
```
"""
Test connections to services
"""
import requests
import socket
from typing import Dict, Tuple

class ConnectionTester:
    def __init__(self):
        self.timeout = 5
        
    def test_connection(self, service_name: str, config: Dict) -> Tuple[bool, str]:
        """Test connection to a service"""
        # Map service names to test methods
        test_methods = {
            "Plex": self._test_plex,
            "Radarr": self._test_radarr,
            "Sonarr": self._test_sonarr,
            "Prowlarr": self._test_prowlarr,
            "Portainer": self._test_portainer,
            "Pi-hole": self._test_pihole,
        }
        
        if service_name in test_methods:
            return test_methods[service_name](config)
        else:
            # Generic test - just check if port is open
            return self._test_generic(config)
            
    def _test_generic(self, config: Dict) -> Tuple[bool, str]:
        """Generic connection test"""
        host = config.get('host', '')
        port = config.get('port', '')
        
        if not host or not port:
            return False, "Missing host or port"
            
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            result = sock.connect_ex((host, int(port)))
            sock.close()
            
            if result == 0:
                return True, f"Connected to {host}:{port}"
            else:
                return False, f"Cannot connect to {host}:{port}"
        except Exception as e:
            return False, str(e)
            
    def _test_plex(self, config: Dict) -> Tuple[bool, str]:
        """Test Plex connection"""
        host = config.get('host', '')
        port = config.get('port', '32400')
        token = config.get('token', '')
        
        try:
            url = f"http://{host}:{port}/identity"
            headers = {'X-Plex-Token': token} if token else {}
            
            response = requests.get(url, headers=headers, timeout=self.timeout)
            if response.status_code == 200:
                return True, "Successfully connected to Plex"
            elif response.status_code == 401:
                return False, "Authentication failed - check token"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
            
    def _test_radarr(self, config: Dict) -> Tuple[bool, str]:
        """Test Radarr connection"""
        host = config.get('host', '')
        port = config.get('port', '7878')
        api_key = config.get('api_key', '')
        base_url = config.get('base_url', '')
        
        try:
            url = f"http://{host}:{port}{base_url}/api/v3/system/status"
            headers = {'X-Api-Key': api_key} if api_key else {}
            
            response = requests.get(url, headers=headers, timeout=self.timeout)
            if response.status_code == 200:
                return True, "Successfully connected to Radarr"
            elif response.status_code == 401:
                return False, "Authentication failed - check API key"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
            
    def _test_sonarr(self, config: Dict) -> Tuple[bool, str]:
        """Test Sonarr connection"""
        # Similar to Radarr
        config['port'] = config.get('port', '8989')
        return self._test_radarr(config)
        
    def _test_prowlarr(self, config: Dict) -> Tuple[bool, str]:
        """Test Prowlarr connection"""
        host = config.get('host', '')
        port = config.get('port', '9696')
        api_key = config.get('api_key', '')
        
        try:
            url = f"http://{host}:{port}/api/v1/system/status"
            headers = {'X-Api-Key': api_key} if api_key else {}
            
            response = requests.get(url, headers=headers, timeout=self.timeout)
            if response.status_code == 200:
                return True, "Successfully connected to Prowlarr"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
            
    def _test_portainer(self, config: Dict) -> Tuple[bool, str]:
        """Test Portainer connection"""
        host = config.get('host', '')
        port = config.get('port', '9000')
        
        try:
            url = f"http://{host}:{port}/api/system/status"
            response = requests.get(url, timeout=self.timeout)
            if response.status_code == 200:
                return True, "Successfully connected to Portainer"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
            
    def _test_pihole(self, config: Dict) -> Tuple[bool, str]:
        """Test Pi-hole connection"""
        host = config.get('host', '')
        port = config.get('port', '80')
        
        try:
            url = f"http://{host}:{port}/admin/api.php?status"
            response = requests.get(url, timeout=self.timeout)
            if response.status_code == 200:
                return True, "Successfully connected to Pi-hole"
            else:
                return False, f"HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
```


=== EXTRACTING SERVICE DEFINITIONS ===
## File: homelab_wizard/services/definitions.py
```
"""
Service definitions for homelab services
"""

# Service categories and their services
SERVICES = {
    "Media Servers": [
        {
            "name": "Plex",
            "icon": "plex",
            "containers": ["plex", "plexmediaserver"],
            "ports": [32400],
            "description": "Media server for streaming content"
        },
        {
            "name": "Jellyfin",
            "icon": "jellyfin",
            "containers": ["jellyfin"],
            "ports": [8096],
            "description": "Free and open source media server"
        },
        {
            "name": "Emby",
            "icon": "emby",
            "containers": ["emby", "embyserver"],
            "ports": [8096],
            "description": "Media server alternative"
        },
    ],
    
    "Media Management": [
        {
            "name": "Radarr",
            "icon": "radarr",
            "containers": ["radarr"],
            "ports": [7878],
            "description": "Movie collection manager"
        },
        {
            "name": "Sonarr",
            "icon": "sonarr",
            "containers": ["sonarr"],
            "ports": [8989],
            "description": "TV show collection manager"
        },
        {
            "name": "Prowlarr",
            "icon": "prowlarr",
            "containers": ["prowlarr"],
            "ports": [9696],
            "description": "Indexer manager for the *arr suite"
        },
    ],
    
    "Network Services": [
        {
            "name": "Nginx Proxy Manager",
            "icon": "nginx",
            "containers": ["nginx-proxy-manager", "nginxproxymanager"],
            "ports": [81],
            "description": "Easy reverse proxy with GUI"
        },
        {
            "name": "Pi-hole",
            "icon": "pihole",
            "containers": ["pihole"],
            "ports": [80, 53],
            "description": "Network-wide ad blocker"
        },
    ],
    
    "Management": [
        {
            "name": "Portainer",
            "icon": "portainer",
            "containers": ["portainer"],
            "ports": [9000],
            "description": "Docker management GUI"
        },
    ],
}

def get_all_services():
    """Get flat list of all services"""
    all_services = []
    for category, services in SERVICES.items():
        all_services.extend(services)
    return all_services

def get_service_by_name(name):
    """Get service info by name"""
    for service in get_all_services():
        if service["name"] == name:
            return service
    return None

# Add these additional services to the SERVICES dictionary
ADDITIONAL_SERVICES = {
    "Download Clients": [
        {
            "name": "qBittorrent",
            "icon": "default",
            "containers": ["qbittorrent", "binhex-qbittorrentvpn"],
            "ports": [8080, 6881, 8999],  # Added alternate ports
            "description": "BitTorrent client"
        },
        {
            "name": "Transmission",
            "icon": "default", 
            "containers": ["transmission"],
            "ports": [9091, 51413],
            "description": "BitTorrent client"
        },
        {
            "name": "Deluge",
            "icon": "default",
            "containers": ["deluge"],
            "ports": [8112, 58846],
            "description": "BitTorrent client"
        },
    ],
    "Monitoring": [
        {
            "name": "Prometheus",
            "icon": "prometheus",
            "containers": ["prometheus"],
            "ports": [9090],
            "description": "Metrics collection"
        },
        {
            "name": "InfluxDB",
            "icon": "default",
            "containers": ["influxdb"],
            "ports": [8086],
            "description": "Time series database"
        },
        {
            "name": "Uptime Kuma",
            "icon": "uptime_kuma",
            "containers": ["uptime-kuma"],
            "ports": [3001],
            "description": "Uptime monitoring"
        },
    ]
}

# Merge with existing services
for category, services in ADDITIONAL_SERVICES.items():
    if category in SERVICES:
        SERVICES[category].extend(services)
    else:
        SERVICES[category] = services

# Make sure all media services have the right ports
MEDIA_SERVICES_UPDATE = {
    "Radarr": [7878],
    "Sonarr": [8989],
    "Prowlarr": [9696],
    "Bazarr": [6767],
    "Lidarr": [8686],
    "Readarr": [8787],
    "Overseerr": [5055],
    "Ombi": [3579],
    "Tautulli": [8181],
}

# Update the services if they exist
for service_name, ports in MEDIA_SERVICES_UPDATE.items():
    for category in SERVICES.values():
        for service in category:
            if service["name"] == service_name:
                service["ports"] = ports
                break
```

## File: homelab_wizard/services/icons.py
```
"""
Icon management for services
"""
import base64
from io import BytesIO
from PIL import Image, ImageTk

# Base64 encoded icons (16x16)
ICON_DATA = {
    "default": "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAA7AAAAOwBeShxvQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAEYSURBVDiNpZOxSgNBEIa/mdm53LvL3V1yMRGJSEQkIiIWFhYWFhYWFhYWPoBPYGFhYWEhCIIgCIIgCIIgGJLk7u72dmf2bSJG4y8MA8PM/3/zzwz8ZwQAIrIELAJ1oAIE/yoMwCJwE2gBNUD4DwAR6QLLQAWoAN0mi7PZLEC1tgAsichPoPIvACJSAUZA1xhTMcaYpuo0m90sy+oBQ0ADuAwMAREhIhdjjBkYYwbVajVot9tBs9kMms1m0Gw2g3a7HbTb7SCKoiCKosCyrCAMQ38X4A3Qi4hhmqZpmqZpnud5nud5nud5nud5nucqz3OV57nK8lwBcwDiLyAgxphBtVoNqtVqEEVRUK/Xg3q9HkRRFIRhGIRhGIRBEPgdgH/AZ+A7ZrQwqEacpEgAAAAASUVORK5CYII=",
    "plex": "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAA7AAAAOwBeShxvQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAHaSURBVDiNpZO/S1VRHMc/53zvvTc1n/pcUZRa5JBDDtHQ0NAQNDS0BQ79A0FDQ0RQU/9BRGNzS0tLNLRFQ0M0REFD5FNR8909957vt+H6Hr0+n4UHzuF8z/fz/X4/3885cMLxAJeABWAe6Ab8v4gDsADMAVPAKpCeBPjABPAJqAGVBqoBS8AEJwRGgWVjzM9YLKZ838c5RxRF7qDCMKRcLqOU2gHGTwLMAl+Louj9zMzM7fHx8a5sNktHRwftbW20tbXR0tJCEAQIIdBaU61WKZVK5PN5NjY2WF1dfQXcPwowBKy7w3p6ehKZTEb19/erwcFBdfb8eda2tvjw+QvBl03S6TRCCJRSOOdwzlEul1ldWeHRw4e8ePqUXDZLFEV3gOL/AB+YN8Z8nZ6ezoyNjQkhBPl8nsXFRV6/eYN1jnQ6jRACrTXWWqy1KKUIggDnHHfu3uXqlSt6YGDA7O3tPQMmGwGzxpjvk5OTmXQ6LT58/Mjr16959fo1xhiklCSTSZIul8PhcDgcDocLgoBYLMaFS5eQUvL06VM1Ojqq8/n8CyC3H+ABH621c7dv3268d++eiqKID58+8e7dO3K5HM45hBAIIVBKoa1Ga40Qgmwuh3OOhYUFbty8qc/19pparTbViE0Bvx9LptFD2gTzAAAAAElFTkSuQmCC",
    # Add more icons as needed
}

def get_icon(service_name):
    """Get PhotoImage icon for a service"""
    icon_key = service_name.lower().replace(" ", "_").replace("-", "_")
    
    # Get icon data
    if icon_key in ICON_DATA:
        icon_b64 = ICON_DATA[icon_key]
    else:
        icon_b64 = ICON_DATA["default"]
    
    # Convert to PhotoImage
    icon_data = base64.b64decode(icon_b64)
    image = Image.open(BytesIO(icon_data))
    return ImageTk.PhotoImage(image)
```


=== EXTRACTING GENERATORS ===
## File: homelab_wizard/generators/documentation_generator.py
```
"""
Documentation generator framework for LaDashy
Generates comprehensive homelab documentation in multiple formats
"""
import os
import json
import yaml
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
import markdown
from jinja2 import Environment, FileSystemLoader, Template

class DocumentationGenerator:
    def __init__(self, output_dir: str = "homelab_docs"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        self.dirs = {
            'services': self.output_dir / 'services',
            'network': self.output_dir / 'network',
            'docker': self.output_dir / 'docker',
            'configs': self.output_dir / 'configs',
            'diagrams': self.output_dir / 'diagrams',
            'assets': self.output_dir / 'assets'
        }
        
        for dir_path in self.dirs.values():
            dir_path.mkdir(exist_ok=True)
            
    def generate_all(self, 
                     discovered_services: Dict,
                     service_configs: Dict,
                     collected_data: Dict) -> Dict[str, str]:
        """Generate all documentation"""
        results = {}
        
        # Generate main index
        results['index'] = self._generate_index(discovered_services, service_configs)
        
        # Generate network topology
        results['network'] = self._generate_network_topology(discovered_services)
        
        # Generate service documentation
        for host, services in discovered_services.items():
            for service in services.get('services', []):
                service_key = f"{service['name']}_{host}"
                results[service_key] = self._generate_service_doc(
                    service, host, 
                    service_configs.get(service_key, {}),
                    collected_data.get(service_key, {})
                )
        
        # Generate Docker compose files
        results['docker'] = self._generate_docker_compose(discovered_services, service_configs)
        
        # Generate dependency map
        results['dependencies'] = self._generate_dependency_map(discovered_services)
        
        # Generate security audit
        results['security'] = self._generate_security_audit(discovered_services, service_configs)
        
        return results
    
    def _generate_index(self, discovered_services: Dict, service_configs: Dict) -> str:
        """Generate main index page"""
        template = """# Homelab Documentation

Generated: {{ timestamp }}

## Overview

This documentation provides a comprehensive view of your homelab infrastructure.

## Quick Stats

- **Total Hosts**: {{ total_hosts }}
- **Total Services**: {{ total_services }}
- **Configured Services**: {{ configured_services }}
- **Docker Containers**: {{ docker_containers }}

## Network Overview

| Host | IP Address | Services | Status |
|------|------------|----------|--------|
{% for host, info in discovered_services.items() %}
| {{ info.hostname }} | {{ host }} | {{ info.services|length }} services | ✅ Active |
{% endfor %}

## Services by Category

### Media Services
{% for host, info in discovered_services.items() %}
{% for service in info.services %}
{% if service.name in ['Plex', 'Jellyfin', 'Emby', 'Radarr', 'Sonarr', 'Prowlarr'] %}
- [{{ service.name }}](services/{{ service.name|lower|replace(' ', '_') }}_{{ host }}.md) on {{ info.hostname }} ({{ host }})
{% endif %}
{% endfor %}
{% endfor %}

### Network Services
{% for host, info in discovered_services.items() %}
{% for service in info.services %}
{% if service.name in ['Pi-hole', 'Nginx Proxy Manager', 'Traefik'] %}
- [{{ service.name }}](services/{{ service.name|lower|replace(' ', '_') }}_{{ host }}.md) on {{ info.hostname }} ({{ host }})
{% endif %}
{% endfor %}
{% endfor %}

### Management Tools
{% for host, info in discovered_services.items() %}
{% for service in info.services %}
{% if service.name in ['Portainer', 'Cockpit', 'Webmin'] %}
- [{{ service.name }}](services/{{ service.name|lower|replace(' ', '_') }}_{{ host }}.md) on {{ info.hostname }} ({{ host }})
{% endif %}
{% endfor %}
{% endfor %}

## Quick Links

- [Network Topology](network/topology.md)
- [Service Dependencies](network/dependencies.md)
- [Docker Compose Files](docker/README.md)
- [Security Audit](security_audit.md)
- [Backup Status](backup_status.md)
"""
        
        # Calculate stats
        total_services = sum(len(info.get('services', [])) for info in discovered_services.values())
        configured_services = len(service_configs)
        docker_containers = sum(
            1 for info in discovered_services.values() 
            for service in info.get('services', [])
            if service.get('container')
        )
        
        # Render template
        from jinja2 import Template
        tmpl = Template(template)
        content = tmpl.render(
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            discovered_services=discovered_services,
            total_hosts=len(discovered_services),
            total_services=total_services,
            configured_services=configured_services,
            docker_containers=docker_containers
        )
        
        # Save to file
        output_path = self.output_dir / 'README.md'
        output_path.write_text(content)
        
        return content
    
    def _generate_service_doc(self, service: Dict, host: str, 
                             config: Dict, data: Dict) -> str:
        """Generate documentation for a single service"""
        template = """# {{ service.name }}

## Overview

- **Host**: {{ hostname }} ({{ host }})
- **Port(s)**: {{ ports }}
- **Confidence**: {{ confidence }}%
- **Type**: {{ service.get('device_type', 'Unknown') }}

## Configuration

{% if config %}
### Current Configuration
```yaml
{{ config | tojson(indent=2) }}
```
{% else %}
❌ **Not Configured** - Add configuration in LaDashy to enable monitoring
{% endif %}

## Connection Details

- **URL**: http://{{ host }}:{{ service.ports[0] if service.ports else 'N/A' }}
{% if config.get('api_key') %}
- **API Key**: ✅ Configured
{% endif %}
{% if config.get('username') %}
- **Username**: {{ config.username }}
{% endif %}

## Docker Compose Example

```yaml
version: '3.8'
services:
  {{ service.name|lower|replace(' ', '-') }}:
    image: # Add appropriate image
    container_name: {{ service.name|lower|replace(' ', '-') }}
    ports:
      - "{{ service.ports[0] if service.ports else 8080 }}:{{ service.ports[0] if service.ports else 8080 }}"
    volumes:
      - ./config:/config
      - ./data:/data
    environment:
      - PUID=1000
      - PGID=1000
      - TZ=America/New_York
    restart: unless-stopped
```

---
*Last Updated: {{ timestamp }}*
"""
        
        # Get hostname
        hostname = 'Unknown'
        
        # Render template
        from jinja2 import Template
        tmpl = Template(template)
        content = tmpl.render(
            service=service,
            host=host,
            hostname=hostname,
            ports=', '.join(str(p) for p in service.get('ports', [])),
            confidence=int(service.get('confidence', 0) * 100),
            config=config,
            data=data,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )
        
        # Save to file
        filename = f"{service['name'].lower().replace(' ', '_')}_{host}.md"
        output_path = self.dirs['services'] / filename
        output_path.write_text(content)
        
        return content
    
    def _generate_network_topology(self, discovered_services: Dict) -> str:
        """Generate network topology diagram and documentation"""
        
        # Create Mermaid diagram
        mermaid_diagram = """graph TB
    subgraph Internet
        WAN[Internet]
    end
    
    subgraph "Home Network"
        Router[Router<br/>192.168.1.1]
        WAN --> Router
"""
        
        # Add discovered hosts
        for host, info in discovered_services.items():
            host_id = host.replace('.', '_')
            services_list = '<br/>'.join(s['name'] for s in info.get('services', [])[:3])
            if len(info.get('services', [])) > 3:
                services_list += '<br/>...'
            
            mermaid_diagram += f"""
        {host_id}[{info['hostname']}<br/>{host}<br/>{services_list}]
        Router --> {host_id}"""
        
        mermaid_diagram += "\n    end"
        
        # Create markdown document
        content = f"""# Network Topology

## Network Diagram

```mermaid
{mermaid_diagram}
```

## Host Details

| Hostname | IP Address | Services | Open Ports |
|----------|------------|----------|------------|
"""
        
        for host, info in discovered_services.items():
            services = ', '.join(s['name'] for s in info.get('services', []))
            ports = ', '.join(str(p) for s in info.get('services', []) for p in s.get('ports', []))
            
            content += f"| {info['hostname']} | {host} | {services} | {ports} |\n"
        
        content += """

---
*Generated: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "*"
        
        # Save to file
        output_path = self.dirs['network'] / 'topology.md'
        output_path.write_text(content)
        
        # Also create an HTML version with interactive diagram
        html_content = self._generate_html_network_diagram(discovered_services)
        html_path = self.dirs['diagrams'] / 'network_topology.html'
        html_path.write_text(html_content)
        
        return content
    
    def _generate_html_network_diagram(self, discovered_services: Dict) -> str:
        """Generate interactive HTML network diagram"""
        return """<!DOCTYPE html>
<html>
<head>
    <title>Homelab Network Topology</title>
    <script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <style>
        #network { width: 100%; height: 600px; border: 1px solid #ccc; }
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; }
        .info { margin: 20px 0; padding: 15px; background: #f5f5f5; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Homelab Network Topology</h1>
    <div class="info">
        <strong>Interactive Network Diagram</strong><br>
        Click and drag to move nodes. Scroll to zoom. Click on a node for details.
    </div>
    <div id="network"></div>
    <script>
        // Create nodes
        var nodes = new vis.DataSet([
            {id: 'internet', label: 'Internet', shape: 'square', color: '#ff6b6b', size: 30},
            {id: 'router', label: 'Router\\n192.168.1.1', shape: 'box', color: '#4ecdc4', size: 25},
""" + '\n'.join([f"""            {{id: '{host.replace(".", "_")}', label: '{info["hostname"]}\\n{host}\\n{len(info.get("services", []))} services', shape: 'box', color: '#45b7d1'}},""" 
                for host, info in discovered_services.items()]) + """
        ]);
        
        // Create edges
        var edges = new vis.DataSet([
            {from: 'internet', to: 'router', width: 3},
""" + '\n'.join([f"""            {{from: 'router', to: '{host.replace(".", "_")}'}},""" 
                for host in discovered_services.keys()]) + """
        ]);
        
        // Create network
        var container = document.getElementById('network');
        var data = { nodes: nodes, edges: edges };
        var options = {
            physics: {
                enabled: true,
                barnesHut: {
                    springConstant: 0.04,
                    avoidOverlap: 0.5
                }
            },
            interaction: {
                hover: true,
                tooltipDelay: 200
            }
        };
        var network = new vis.Network(container, data, options);
    </script>
</body>
</html>"""
    
    def _generate_dependency_map(self, discovered_services: Dict) -> str:
        """Generate service dependency map"""
        content = """# Service Dependencies

## Dependency Graph

```mermaid
graph LR
    subgraph "Media Stack"
        Plex[Plex Media Server]
        Radarr[Radarr]
        Sonarr[Sonarr]
        Prowlarr[Prowlarr]
        
        Prowlarr -->|Indexers| Radarr
        Prowlarr -->|Indexers| Sonarr
        Radarr -->|Movies| Plex
        Sonarr -->|TV Shows| Plex
    end
    
    subgraph "Download Stack"
        qBittorrent[qBittorrent]
        Radarr -->|Downloads| qBittorrent
        Sonarr -->|Downloads| qBittorrent
    end
    
    subgraph "Network Services"
        NPM[Nginx Proxy Manager]
        NPM -->|Reverse Proxy| Plex
        NPM -->|Reverse Proxy| Radarr
        NPM -->|Reverse Proxy| Sonarr
    end
```

---
*Generated: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "*"
        
        # Save to file
        output_path = self.dirs['network'] / 'dependencies.md'
        output_path.write_text(content)
        
        return content
    
    def _generate_docker_compose(self, discovered_services: Dict, service_configs: Dict) -> str:
        """Generate Docker compose configurations"""
        
        # Main compose file
        compose_content = """version: '3.8'

networks:
  homelab:
    driver: bridge

services:
"""
        
        # Add each discovered service
        service_num = 10
        for host, info in discovered_services.items():
            for service in info.get('services', []):
                if service.get('container'):
                    service_name = service['name'].lower().replace(' ', '-')
                    compose_content += f"""
  {service_name}:
    image: # TODO: Add image for {service['name']}
    container_name: {service_name}
    ports:
      - "{service['ports'][0] if service.get('ports') else 8080}:{service['ports'][0] if service.get('ports') else 8080}"
    volumes:
      - ./config/{service_name}:/config
    environment:
      - PUID=1000
      - PGID=1000
      - TZ=America/New_York
    restart: unless-stopped
"""
                    service_num += 1
        
        # Save main compose file
        compose_path = self.dirs['docker'] / 'docker-compose.yml'
        compose_path.write_text(compose_content)
        
        # Create README for docker directory
        docker_readme = """# Docker Compose Files

This directory contains Docker Compose configurations for your homelab services.

## Usage

```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# View logs
docker-compose logs -f service-name
```
"""
        
        readme_path = self.dirs['docker'] / 'README.md'
        readme_path.write_text(docker_readme)
        
        return compose_content
    
    def _generate_security_audit(self, discovered_services: Dict, service_configs: Dict) -> str:
        """Generate security audit report"""
        content = f"""# Security Audit Report

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Executive Summary

This security audit provides an overview of your homelab's security posture.

## Exposed Services

### Externally Accessible Services

| Service | Host | Port | Protection |
|---------|------|------|------------|
"""
        
        # Check for services on common web ports
        for host, info in discovered_services.items():
            for service in info.get('services', []):
                for port in service.get('ports', []):
                    if port in [80, 443, 8080, 8443]:
                        protection = "⚠️ Check reverse proxy" if port in [80, 8080] else "✅ HTTPS"
                        content += f"| {service['name']} | {host} | {port} | {protection} |\n"
        
        content += """

## Security Checklist

### Access Control
- [ ] All services behind reverse proxy with authentication
- [ ] Strong passwords on all services (min 16 characters)
- [ ] 2FA enabled where available
- [ ] API keys rotated regularly
- [ ] Default credentials changed

### Network Security
- [ ] Firewall enabled and configured
- [ ] Only necessary ports exposed
- [ ] VLANs configured for network segmentation
- [ ] VPN for remote access (not port forwarding)
- [ ] Regular security updates applied

---
*This is an automated security audit. For comprehensive security assessment, consider professional penetration testing.*
"""
        
        # Save to file
        output_path = self.output_dir / 'security_audit.md'
        output_path.write_text(content)
        
        return content
    
    def export_to_json(self, discovered_services: Dict, service_configs: Dict, 
                      collected_data: Dict) -> str:
        """Export all data to JSON for AI assistant consumption"""
        export_data = {
            'generated': datetime.now().isoformat(),
            'summary': {
                'total_hosts': len(discovered_services),
                'total_services': sum(len(info.get('services', [])) for info in discovered_services.values()),
                'configured_services': len(service_configs)
            },
            'discovered_services': discovered_services,
            'service_configurations': service_configs,
            'collected_data': collected_data
        }
        
        # Save to file
        json_path = self.output_dir / 'homelab_data.json'
        with open(json_path, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        return json.dumps(export_data, indent=2)
    
    def export_to_html_dashboard(self, discovered_services: Dict, 
                                service_configs: Dict) -> str:
        """Generate an HTML dashboard"""
        html_content = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homelab Dashboard</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 0;
            background: #1a1a1a;
            color: #e0e0e0;
        }
        .header {
            background: #2d2d2d;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .header h1 {
            margin: 0;
            color: #4ecdc4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .stat-card {
            background: #2d2d2d;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
        }
        .stat-card h3 {
            margin: 0 0 10px 0;
            color: #96ceb4;
        }
        .stat-card .value {
            font-size: 2em;
            font-weight: bold;
            color: #4ecdc4;
        }
        .services {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .service-card {
            background: #2d2d2d;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            transition: transform 0.2s;
        }
        .service-card:hover {
            transform: translateY(-5px);
        }
        .service-card h4 {
            margin: 0 0 10px 0;
            color: #4ecdc4;
        }
        .service-info {
            font-size: 0.9em;
            color: #b0b0b0;
        }
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 5px;
        }
        .status-active { background: #96ceb4; }
        .status-configured { background: #ffd93d; }
        .status-error { background: #ff6b6b; }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <h1>🏠 Homelab Dashboard</h1>
            <p>Generated: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</p>
        </div>
    </div>
    
    <div class="container">
        <div class="stats">
            <div class="stat-card">
                <h3>Total Hosts</h3>
                <div class="value">""" + str(len(discovered_services)) + """</div>
            </div>
            <div class="stat-card">
                <h3>Total Services</h3>
                <div class="value">""" + str(sum(len(info.get('services', [])) for info in discovered_services.values())) + """</div>
            </div>
            <div class="stat-card">
                <h3>Configured</h3>
                <div class="value">""" + str(len(service_configs)) + """</div>
            </div>
        </div>
        
        <h2>Services</h2>
        <div class="services">
"""
        
        # Add service cards
        for host, info in discovered_services.items():
            for service in info.get('services', []):
                service_key = f"{service['name']}_{host}"
                is_configured = service_key in service_configs
                
                html_content += f"""
            <div class="service-card">
                <h4>
                    <span class="status-indicator status-{'configured' if is_configured else 'active'}"></span>
                    {service['name']}
                </h4>
                <div class="service-info">
                    <p><strong>Host:</strong> {info['hostname']} ({host})</p>
                    <p><strong>Port:</strong> {', '.join(str(p) for p in service.get('ports', []))}</p>
                    <p><strong>Status:</strong> {'Configured' if is_configured else 'Discovered'}</p>
                </div>
            </div>
"""
        
        html_content += """
        </div>
    </div>
</body>
</html>"""
        
        # Save to file
        dashboard_path = self.output_dir / 'dashboard.html'
        dashboard_path.write_text(html_content)
        
        return html_content


# Integration function for LaDashy
def generate_documentation(discovered_services: Dict, 
                         service_configs: Dict,
                         collected_data: Dict,
                         output_dir: str = "homelab_docs") -> Dict[str, str]:
    """
    Main entry point for documentation generation
    
    Args:
        discovered_services: Services discovered by scanner
        service_configs: Configuration for each service
        collected_data: Live data collected from services
        output_dir: Output directory for documentation
    
    Returns:
        Dictionary of generated file paths
    """
    generator = DocumentationGenerator(output_dir)
    
    # Generate all documentation
    results = generator.generate_all(discovered_services, service_configs, collected_data)
    
    # Export to different formats
    generator.export_to_json(discovered_services, service_configs, collected_data)
    generator.export_to_html_dashboard(discovered_services, service_configs)
    
    return results
```


=== EXTRACTING CONFIGURATION ===
## File: requirements.txt
```
# Web Framework
flask==3.0.0
flask-cors==4.0.0

# Existing dependencies
requests==2.31.0
paramiko==3.4.0
jinja2==3.1.2
markdown==3.5.1
pyyaml==6.0.1

# For desktop UI (optional)
customtkinter==5.2.1
pillow==10.2.0
```

## File: generate_session.sh
```
#!/bin/bash
SECTION=$1

if [ -z "$SECTION" ]; then
    echo "Usage: ./generate_session.sh [01|02|03|04|05]"
    echo "  01 - Backend API"
    echo "  02 - Frontend"
    echo "  03 - Icons"
    echo "  04 - Dashboard"
    echo "  05 - Collectors"
    exit 1
fi

OUTPUT="SESSION_CONTEXT_$(date +%Y%m%d_%H%M%S).md"

echo "# LaDashy Session Context" > $OUTPUT
echo "## Working on: SECTION_$SECTION" >> $OUTPUT
echo "## Generated: $(date)" >> $OUTPUT
echo "" >> $OUTPUT
echo "Tell the AI you're working on Section $SECTION" >> $OUTPUT
echo "Ask it to check PROJECT_MANAGER.md for details" >> $OUTPUT

echo "✅ Created: $OUTPUT"
echo "📋 Upload this file to your AI chat!"
```


=== CHECKING PROJECT STRUCTURE ===
```
./add_scan_debugging.py
./backend/api.py
./check_js_syntax.py
./check_syntax_error.py
./current_index.html
./desktop/main.js
./ensure_api_url.py
./ensure_global_functions.py
./fix_api_url.py
./fix_apikey_duplicate.py
./fix_duplicate_api_url.py
./fix_frontend_api_calls.py
./fix_function_scope.py
./fix_network_scanner.py
./fix_script_structure.py
./fix_script_tags.py
./fix_startscan_function.py
./fix_template_literal.py
./fix_with_event_listeners.py
./frontend/add_debugging_again.py
./frontend/fix_all_functions.py
./frontend/fix_function_access.py
./frontend/improve_progress_display.py
./frontend/index.html
./frontend/service-icons.js
./frontend/test-icons.html
./frontend/update-icons.js
./homelab_wizard/__init__.py
./homelab_wizard/collectors/__init__.py
./homelab_wizard/collectors/base_collector.py
./homelab_wizard/collectors/jellyfin_collector.py
./homelab_wizard/collectors/manager.py
./homelab_wizard/collectors/manager_update.py
./homelab_wizard/collectors/pihole_collector.py
./homelab_wizard/collectors/plex_collector.py
./homelab_wizard/collectors/portainer_collector.py
./homelab_wizard/collectors/radarr_collector.py
./homelab_wizard/collectors/sonarr_collector.py
./homelab_wizard/core/__init__.py
./homelab_wizard/core/connection_tester.py
./homelab_wizard/core/docker_scanner.py
./homelab_wizard/core/scanner.py
./homelab_wizard/core/scanner_fixed.py
./homelab_wizard/core/scanner_improved.py
./homelab_wizard/core/scanner_quiet.py
./homelab_wizard/core/scanner_update.py
./homelab_wizard/core/service_detector.py
./homelab_wizard/core/service_detector_fix.py
./homelab_wizard/generators/__init__.py
./homelab_wizard/generators/documentation_generator.py
./homelab_wizard/gui/__init__.py
./homelab_wizard/gui/add_documentation_tab.py
./homelab_wizard/gui/config_panel.py
./homelab_wizard/gui/discovered_tab_update.py
./homelab_wizard/gui/documentation_panel.py
./homelab_wizard/gui/enhanced_service_list.py
./homelab_wizard/gui/main_window.py
./homelab_wizard/gui/main_window_update.py
./homelab_wizard/gui/modern_main_window.py
./homelab_wizard/gui/modern_main_window_integration.py
./homelab_wizard/gui/modern_main_window_update.py
./homelab_wizard/gui/modern_ui.py
./homelab_wizard/gui/modern_ui_fixed.py
./homelab_wizard/gui/network_config.py
./homelab_wizard/gui/network_config_fixed.py
./homelab_wizard/gui/network_config_fixed2.py
./homelab_wizard/gui/network_config_simple.py
./homelab_wizard/gui/scan_dialog.py
./homelab_wizard/gui/scan_dialog_fixed.py
./homelab_wizard/gui/scan_dialog_update.py
./homelab_wizard/gui/service_info_panel.py
./homelab_wizard/gui/service_list.py
./homelab_wizard/gui/service_override.py
./homelab_wizard/services/__init__.py
./homelab_wizard/services/definitions.py
./homelab_wizard/services/icons.py
./homelab_wizard/utils/__init__.py
./launch.py
./save_fixed_index.py
./shared/core.py
./test_api.py
./test_fixed.html
./test_scan.html
./tests/test_api_endpoints.py
./tests/test_config.py
./thorough_syntax_check.py
```

=== CHECKING FOR RECENT CHANGES ===
```
 M frontend/index.html
 M homelab_wizard/collectors/__pycache__/manager.cpython-312.pyc
 M homelab_wizard/core/__pycache__/scanner.cpython-312.pyc
 M homelab_wizard/core/scanner.py
?? LADASHY_FULL_CODE_20250801_214815.md
?? SESSION_CONTEXT_20250801_135332.md
?? SESSION_CONTEXT_20250801_143358.md
?? SESSION_CONTEXT_20250801_143842.md
?? add_scan_debugging.py
?? api.log
?? api.pid
?? backend/api.py.backup_section01
?? backend_status.txt
?? backend_status_updated.txt
?? check_js_syntax.py
?? check_syntax_error.py
?? create_safe_file.sh
?? current_index.html
?? dashboard_with_radarr.yaml
?? docs/project_knowledge/COMPLETED_SESSIONS/
?? docs/project_knowledge/PROGRESS_TRACKER.md
?? docs/project_knowledge/PROGRESS_TRACKER.md:Zone.Identifier
?? docs/project_knowledge/QUICK_REFERENCE.md
?? docs/project_knowledge/QUICK_REFERENCE.md:Zone.Identifier
?? docs/project_knowledge/SECTION_01_BACKEND_API/README.md
?? docs/project_knowledge/SECTION_02_FRONTEND_STATE/
?? docs/project_knowledge/SESSION_CLOSEOUT_GUIDE.md
?? docs/project_knowledge/SESSION_CLOSEOUT_GUIDE.md:Zone.Identifier
?? docs/project_knowledge/SESSION_WORKFLOW_GUIDE.md
?? docs/project_knowledge/SESSION_WORKFLOW_GUIDE.md:Zone.Identifier
?? docs/project_knowledge/ladashy_code_guide.md
?? ensure_api_url.py
?? ensure_global_functions.py
?? fix_api_url.py
?? fix_apikey_duplicate.py
?? fix_duplicate_api_url.py
?? fix_frontend_api_calls.py
?? fix_function_scope.py
?? fix_network_scanner.py
?? fix_script_structure.py
?? fix_script_tags.py
?? fix_startscan_function.py
?? fix_template_literal.py
?? fix_with_event_listeners.py
?? frontend.pid
?? frontend/.index.html.swp
?? frontend/SESSION_02_HANDOFF.md
?? frontend/add_debugging_again.py
?? frontend/fix_all_functions.py
?? frontend/fix_function_access.py
?? frontend/frontend.log
?? frontend/improve_progress_display.py
?? frontend/index.html.broken
?? frontend/index.html.broken_20250801_172511
?? frontend/index.html.broken_20250801_203742
?? frontend/index.html.broken_again
?? frontend/index.html.test
?? frontend/index.html:Zone.Identifier
?? frontend/restart_ladashy.sh
?? generated_dashboard.yaml
?? homelab_wizard/collectors/__pycache__/jellyfin_collector.cpython-312.pyc
?? homelab_wizard/collectors/__pycache__/pihole_collector.cpython-312.pyc
?? homelab_wizard/collectors/__pycache__/portainer_collector.cpython-312.pyc
?? javascript_section.txt
?? save_fixed_index.py
?? test_fixed.html
?? test_scan.html
?? thorough_syntax_check.py

Last 5 commits:
528f20a [DOCS] Section 01 complete - Backend fully functional with tests
5356560 [TESTS] Added comprehensive test infrastructure and management scripts
ff09b00 [ENHANCE] Added all implemented collectors (Jellyfin, Portainer, Pi-hole) to CollectorManager
81279f5 [FIX] Section 01 COMPLETE - Backend API test endpoint working - Fixed collector initialization and method signatures
af08440 [DOCS] Complete session management system setup - ready for Section 01
```
