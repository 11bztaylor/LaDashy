#!/usr/bin/env python3

with open('frontend/index.html', 'r') as f:
    content = f.read()

# Find the startScan function and add debugging
import re

# Add console.log to see what networks are being sent
old_scan = '''const networks = document.getElementById('network-range').value
                .split(',')
                .map(n => n.trim())
                .filter(n => n);'''

new_scan = '''const networks = document.getElementById('network-range').value
                .split(',')
                .map(n => n.trim())
                .filter(n => n);
            
            console.log('Network input value:', document.getElementById('network-range').value);
            console.log('Parsed networks:', networks);'''

content = content.replace(old_scan, new_scan)

# Add logging to see the scan response
old_fetch = '''body: JSON.stringify({ networks })
                });
                
                if (response.ok) {'''

new_fetch = '''body: JSON.stringify({ networks })
                });
                
                console.log('Sending to backend:', { networks });
                const data = await response.json();
                console.log('Backend response:', data);
                
                if (response.ok) {'''

content = content.replace(old_fetch, new_fetch)

# Fix the progress bar calculation in checkScanStatus
old_progress = '''// Estimate progress
                    const progress = Math.min((status.services_found || 0) * 10, 90);'''

new_progress = '''// Calculate progress based on scanning status
                    if (status.progress && status.progress.includes('/')) {
                        // Extract "X hosts in Y" pattern
                        const match = status.progress.match(/(\d+) hosts in/);
                        const hostsScanned = match ? parseInt(match[1]) : 0;
                        const totalHosts = 254; // Typical /24 network
                        const progress = Math.min((hostsScanned / totalHosts) * 100, 95);
                        document.getElementById('progress-fill').style.width = progress + '%';
                    } else {
                        // Fallback
                        const progress = Math.min((status.services_found || 0) * 10, 90);
                        document.getElementById('progress-fill').style.width = progress + '%';
                    }'''

content = content.replace(old_progress, new_progress)

with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Added debugging to scan function")
