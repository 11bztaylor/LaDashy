#!/usr/bin/env python3
import re

# Read the HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Extract the script content
script_match = re.search(r'<script>(.*?)</script>', content, re.DOTALL)
if script_match:
    script_content = script_match.group(1)
    
    # Find the line number where startScan is defined
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if 'async function startScan' in line:
            print(f"startScan function found at line {i+1}")
            
    # Check for common syntax issues
    print("\nChecking for syntax issues:")
    
    # Check for unclosed strings
    single_quotes = script_content.count("'") 
    double_quotes = script_content.count('"')
    backticks = script_content.count('`')
    
    print(f"Single quotes: {single_quotes} (should be even)")
    print(f"Double quotes: {double_quotes} (should be even)")
    print(f"Backticks: {backticks} (should be even)")
    
    # Check for unclosed brackets/braces
    open_parens = script_content.count('(')
    close_parens = script_content.count(')')
    open_braces = script_content.count('{')
    close_braces = script_content.count('}')
    open_brackets = script_content.count('[')
    close_brackets = script_content.count(']')
    
    print(f"\nParentheses: {open_parens} open, {close_parens} close")
    print(f"Braces: {open_braces} open, {close_braces} close")
    print(f"Brackets: {open_brackets} open, {close_brackets} close")
    
    # Look for the specific error around line 923
    if len(lines) > 923:
        print(f"\nLine 923: {lines[922].strip()}")
