#!/usr/bin/env python3
import re

with open('frontend/index.html', 'r') as f:
    content = f.read()

# Extract just the JavaScript
script_match = re.search(r'<script>(.*?)</script>', content, re.DOTALL)
if script_match:
    js_content = script_match.group(1)
    
    # Find line 1021 in the original file
    lines = content.split('\n')
    if len(lines) > 1020:
        print(f"Line 1021: {lines[1020]}")
        print(f"Line 1020: {lines[1019]}")
        print(f"Line 1022: {lines[1021]}")
    
    # Check for common syntax issues
    # Count braces in startScan function area
    start_pos = js_content.find('async function startScan')
    if start_pos > -1:
        # Get next 500 characters
        snippet = js_content[start_pos:start_pos+1000]
        open_count = snippet.count('{')
        close_count = snippet.count('}')
        print(f"\nIn startScan area: {open_count} open braces, {close_count} close braces")
        
        if close_count > open_count:
            print("ERROR: Too many closing braces!")
