#!/bin/bash
# Safe file creation helper

create_file() {
    local filepath=$1
    local content=$2
    echo "$content" > "$filepath"
    echo "✅ Created: $filepath"
}

# Usage: ./create_safe_file.sh
