# Quick Command Reference
cd /home/zach/homelab-documentation/ladashy_unified
source ../homelab-env/bin/activate
python backend/api.py
