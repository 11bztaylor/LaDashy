#!/usr/bin/env python3
import re

# Read the current HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Check if API_URL exists
if 'const API_URL' not in content:
    # Add it after the <script> tag and before other variables
    pattern = r'(<script>\s*\n\s*// API Configuration\s*\n)'
    replacement = r'\1        const API_URL = "http://localhost:5000/api";\n'
    content = re.sub(pattern, replacement, content)
    print("Added API_URL declaration")
    
    # Save the content
    with open('frontend/index.html', 'w') as f:
        f.write(content)
else:
    print("API_URL already exists")
