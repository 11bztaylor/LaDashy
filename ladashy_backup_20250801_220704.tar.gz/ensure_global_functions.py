#!/usr/bin/env python3

# Read the file
with open('frontend/index.html', 'r') as f:
    lines = f.readlines()

# Find the line after API_URL definition to add global function declarations
insert_index = -1
for i, line in enumerate(lines):
    if 'const API_URL' in line:
        insert_index = i + 1
        break

if insert_index > 0:
    # Add global function declarations
    global_declarations = '''        
        // Make functions globally accessible for onclick handlers
        window.startScan = async function() {
            const networks = document.getElementById('network-range').value
                .split(',')
                .map(n => n.trim())
                .filter(n => n);

            if (networks.length === 0) {
                showToast('Please enter at least one network range', 'error');
                return;
            }

            document.getElementById('btn-scan').disabled = true;
            document.getElementById('progress').classList.add('active');

            try {
                const response = await fetch(`${API_URL}/scan`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ networks })
                });

                if (response.ok) {
                    showToast('Network scan started!', 'success');
                    scanInterval = setInterval(checkScanStatus, 1000);
                } else {
                    throw new Error('Failed to start scan');
                }
            } catch (error) {
                showToast('Failed to start scan: ' + error.message, 'error');
                document.getElementById('btn-scan').disabled = false;
                document.getElementById('progress').classList.remove('active');
            }
        };
        
'''
    lines.insert(insert_index, global_declarations)
    
    # Write back
    with open('frontend/index.html', 'w') as f:
        f.writelines(lines)
    
    print("Added window.startScan declaration")
else:
    print("Could not find insertion point")
