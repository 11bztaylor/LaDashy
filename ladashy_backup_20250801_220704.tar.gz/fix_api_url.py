#!/usr/bin/env python3

# Read the current HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Find the <script> tag and add API_URL at the beginning
import re

# Pattern to find the opening script tag
script_pattern = r'(<script>)'

# The API_URL definition to add
api_url_definition = '''<script>
        // API Configuration
        const API_URL = 'http://localhost:5000/api';
'''

# Replace the first <script> tag with our new one that includes API_URL
content = re.sub(script_pattern, api_url_definition, content, count=1)

# Save the fixed content
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("API_URL has been defined!")
print("Added: const API_URL = 'http://localhost:5000/api';")
