#!/usr/bin/env python3

# Read the file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Find and remove the second apiKey declaration block (lines 965-971)
lines = content.split('\n')

# Look for the pattern and remove the duplicate block
new_lines = []
skip_count = 0

for i, line in enumerate(lines):
    # Start skipping at the second "const apiKey = " after line 960
    if i > 960 and i < 975 and 'const apiKey = document.getElementById' in line:
        skip_count = 7  # Skip this line and the next 6 lines
        print(f"Removing duplicate apiKey block starting at line {i+1}")
    
    if skip_count > 0:
        skip_count -= 1
        continue
        
    new_lines.append(line)

# Join and save
content = '\n'.join(new_lines)
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Fixed duplicate apiKey declaration!")
