#!/usr/bin/env python3
import re

# Read the current HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Count how many times API_URL is declared
api_url_declarations = len(re.findall(r'(?:const|let|var)\s+API_URL\s*=', content))
print(f"Found {api_url_declarations} API_URL declarations")

# If there are multiple, keep only the first one
if api_url_declarations > 1:
    # Find all declarations
    matches = list(re.finditer(r'(?:const|let|var)\s+API_URL\s*=.*?;', content))
    
    # Remove all but the first
    for match in matches[1:]:
        content = content.replace(match.group(0), '')
        print(f"Removed duplicate: {match.group(0)}")

# Save the fixed content
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Fixed duplicate API_URL declarations!")
