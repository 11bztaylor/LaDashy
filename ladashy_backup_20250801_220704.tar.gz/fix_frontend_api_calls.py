#!/usr/bin/env python3
import re

# Read the current HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Fix 1: Update startScan to use correct endpoint
old_scan_pattern = r"fetch\(['\"].*?/api/discover['\"]"
new_scan_pattern = "fetch('/api/scan'"
content = re.sub(old_scan_pattern, new_scan_pattern, content)

# Fix 2: Ensure startScan sends POST with correct data
# Find the startScan function and check if it's sending the right data
if "function startScan" in content:
    # Make sure it's using POST method with networks data
    scan_func_pattern = r"(async function startScan\(\)[^{]*{[^}]*fetch\([^)]+\))"
    
    def fix_scan_function(match):
        func_content = match.group(0)
        if "method: 'POST'" not in func_content:
            # Need to add proper fetch call
            return func_content.replace("fetch('/api/scan'", 
                "fetch('/api/scan', {\n                method: 'POST',\n                headers: { 'Content-Type': 'application/json' },\n                body: JSON.stringify({ networks: networks })\n            }")
        return func_content
    
    content = re.sub(scan_func_pattern, fix_scan_function, content, flags=re.DOTALL)

# Fix 3: Update any references to /api/discover to /api/scan
content = content.replace('/api/discover', '/api/scan')

# Fix 4: Ensure generate function uses correct endpoint
content = content.replace("fetch('/api/dashboard/generate'", "fetch('/api/generate'")

# Save the fixed content
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Frontend API calls have been updated!")
print("\nChanges made:")
print("1. Updated /api/discover to /api/scan")
print("2. Ensured startScan sends POST request with networks data")
print("3. Updated dashboard generate endpoint")
