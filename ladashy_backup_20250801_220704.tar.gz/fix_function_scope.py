#!/usr/bin/env python3
import re

# Read the file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Check if functions are wrapped in any IIFE or other scope
script_match = re.search(r'<script>(.*?)</script>', content, re.DOTALL)
if script_match:
    script_content = script_match.group(1)
    
    # Check if there's an IIFE pattern
    if '(function()' in script_content or '(() =>' in script_content:
        print("Functions are wrapped in an IIFE - they won't be globally accessible!")
    else:
        print("Functions should be global. Checking for other issues...")

# Make sure critical functions are attached to window object
# Add window references for onclick handlers
fixes = [
    ('function startScan()', 'function startScan()'),
    ('function showManualAdd()', 'function showManualAdd()'),
    ('function saveConfig()', 'function saveConfig()'),
    ('function testServiceConnection()', 'function testServiceConnection()')
]

for old, new in fixes:
    if old in content:
        # Add window attachment after function definition
        pattern = f'({old}.*?}})'
        def add_window_ref(match):
            func_name = old.split(' ')[1].split('(')[0]
            return match.group(0) + f'\n        window.{func_name} = {func_name};'
        
        content = re.sub(pattern, add_window_ref, content, flags=re.DOTALL)

# Alternative: Change onclick handlers to use event listeners
# This is more reliable but requires more changes

with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Added window references for onclick handlers")
