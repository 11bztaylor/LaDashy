#!/usr/bin/env python3

# Fix the scanner.py hardcoded network
with open('homelab_wizard/core/scanner.py', 'r') as f:
    content = f.read()

# Remove the hardcoded default network
content = content.replace(
    'self.networks = ["192.168.1.0/24"]  # Default network',
    'self.networks = []  # No default network - use what user provides'
)

with open('homelab_wizard/core/scanner.py', 'w') as f:
    f.write(content)

print("Fixed scanner.py - removed hardcoded network")

# Now check the backend API scan endpoint
with open('backend/api.py', 'r') as f:
    api_content = f.read()

# Let's look for the scan endpoint
import re
scan_match = re.search(r'@app\.route\(\'/api/scan.*?\n(.*?)(?=@app\.route|$)', api_content, re.DOTALL)
if scan_match:
    print("\nCurrent scan endpoint code:")
    print(scan_match.group(0)[:500] + "...")
