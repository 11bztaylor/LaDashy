#!/usr/bin/env python3

# Read the current HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Remove the extra script tag at the end
content = content.replace('</body>\n</html>\n<script src="update-icons.js"></script>', 
                         '<script src="update-icons.js"></script>\n</body>\n</html>')

# Make sure API_URL is defined at the beginning of the script section
if 'const API_URL' not in content:
    # Find the first <script> tag and add API_URL right after it
    import re
    pattern = r'(<script>\s*\n\s*//[^\n]*\n)'
    replacement = r'\1        const API_URL = "http://localhost:5000/api";\n'
    content = re.sub(pattern, replacement, content, count=1)
    print("Added API_URL declaration")

# Save the fixed content
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Fixed script structure!")
print("- Moved update-icons.js script tag to proper location")
print("- Ensured API_URL is defined")
