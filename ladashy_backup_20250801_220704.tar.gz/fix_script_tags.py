#!/usr/bin/env python3

# Read the file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Find and fix any issues with script tags
# Make sure service-icons.js comes AFTER the main script, not before
import re

# Check current structure
if '<script src="service-icons.js"></script>' in content:
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if '<script src="service-icons.js"></script>' in line and i < 900:
            print(f"Found service-icons.js at line {i+1} - this is too early!")
            # Remove it from here
            content = content.replace(line + '\n', '')
            break

# Ensure scripts are in correct order at the end
if content.endswith('</html>'):
    content = content.replace('</html>', '</html>\n')
    
# Write back
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Fixed script tag order")
