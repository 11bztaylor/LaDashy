#!/usr/bin/env python3
import re

# Read the current HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Find and fix the startScan function
# Look for the pattern and check if it's complete
pattern = r'(async function startScan\(\) \{[\s\S]*?)(\n\s*async function)'

def check_and_fix_startscan(match):
    func_content = match.group(1)
    next_func = match.group(2)
    
    # Count braces in the function
    open_braces = func_content.count('{')
    close_braces = func_content.count('}')
    
    if open_braces > close_braces:
        # Function is incomplete, add the missing part
        missing_code = '''
            document.getElementById('btn-scan').disabled = true;
            document.getElementById('progress').classList.add('active');

            try {
                const response = await fetch(`${API_URL}/scan`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ networks: networks })
                });

                const data = await response.json();
                showToast(data.status || 'Scan started', 'success');

                // Start polling for status
                scanInterval = setInterval(checkScanStatus, 2000);
            } catch (error) {
                console.error('Scan error:', error);
                showToast('Failed to start scan: ' + error.message, 'error');
                document.getElementById('btn-scan').disabled = false;
                document.getElementById('progress').classList.remove('active');
            }
        }'''
        
        return func_content + missing_code + next_func
    
    return match.group(0)

# Apply the fix
content = re.sub(pattern, check_and_fix_startscan, content)

# Save the fixed content
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Fixed startScan function!")
