#!/usr/bin/env python3

# Read the current HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Fix the double backtick issue on line 923
# Replace double backticks with single backticks
content = content.replace('``Default: ${service.defaultPort}``', '`Default: ${service.defaultPort}`')

# Also check for any other double backtick issues
import re
double_backtick_pattern = r'``([^`]+)``'
matches = re.findall(double_backtick_pattern, content)
if matches:
    print(f"Found {len(matches)} other double backtick issues")
    for match in matches:
        content = content.replace(f'``{match}``', f'`{match}`')

# Save the fixed content
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Fixed template literal syntax error!")
print("Changed ``Default: ${service.defaultPort}`` to `Default: ${service.defaultPort}`")
