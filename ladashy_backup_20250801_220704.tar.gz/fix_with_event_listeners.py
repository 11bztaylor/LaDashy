#!/usr/bin/env python3

# Read the file  
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Add event listener setup at the end of the script
event_listener_code = '''
        // Set up event listeners for buttons with onclick issues
        document.addEventListener('DOMContentLoaded', function() {
            // Fix scan button
            const scanBtn = document.getElementById('btn-scan');
            if (scanBtn) {
                scanBtn.onclick = function() {
                    if (typeof startScan === 'function') {
                        startScan();
                    } else {
                        console.error('startScan function not found');
                    }
                };
            }
            
            // Fix manual add button
            const manualAddBtns = document.querySelectorAll('[onclick="showManualAdd()"]');
            manualAddBtns.forEach(btn => {
                btn.onclick = function() {
                    if (typeof showManualAdd === 'function') {
                        showManualAdd();
                    } else {
                        console.error('showManualAdd function not found');
                    }
                };
            });
            
            console.log('Event listeners attached');
            console.log('startScan exists:', typeof startScan);
            console.log('showManualAdd exists:', typeof showManualAdd);
        });
'''

# Insert before the closing script tag
content = content.replace('    </script>', event_listener_code + '\n    </script>')

# Write back
with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Added event listener setup")
