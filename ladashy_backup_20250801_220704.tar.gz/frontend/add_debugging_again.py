#!/usr/bin/env python3

with open('index.html', 'r') as f:
    content = f.read()

# Add console logging to startScan
import re

# Find startScan and add debugging
pattern = r'(async function startScan\(\) \{.*?)(fetch\(`\${API_URL}/scan`)'
replacement = r'\1console.log("Network input:", document.getElementById("network-range").value);\n            console.log("Sending networks:", networks);\n            \2'

content = re.sub(pattern, replacement, content, flags=re.DOTALL)

# Add response logging
content = content.replace(
    'if (response.ok) {',
    'const data = await response.json();\n                console.log("Scan response:", data);\n                if (response.ok) {'
)

with open('index.html', 'w') as f:
    f.write(content)

print("Added debugging to index.html")
