#!/usr/bin/env python3

with open('index.html', 'r') as f:
    content = f.read()

# Find the end of the script section and add window assignments
import re

# Find where to insert (before the closing script tag)
insert_point = content.rfind('</script>')

if insert_point > 0:
    # Add window assignments for all critical functions
    window_assignments = '''
        // Make functions globally accessible for onclick handlers
        if (typeof startScan !== 'undefined') window.startScan = startScan;
        if (typeof showManualAdd !== 'undefined') window.showManualAdd = showManualAdd;
        if (typeof configureService !== 'undefined') window.configureService = configureService;
        if (typeof testService !== 'undefined') window.testService = testService;
        if (typeof saveConfig !== 'undefined') window.saveConfig = saveConfig;
        if (typeof addManualService !== 'undefined') window.addManualService = addManualService;
        if (typeof closeConfigModal !== 'undefined') window.closeConfigModal = closeConfigModal;
        if (typeof closeManualAddModal !== 'undefined') window.closeManualAddModal = closeManualAddModal;
        if (typeof showGenerateOptions !== 'undefined') window.showGenerateOptions = showGenerateOptions;
        if (typeof hideGenerateOptions !== 'undefined') window.hideGenerateOptions = hideGenerateOptions;
        if (typeof generateDocs !== 'undefined') window.generateDocs = generateDocs;
        if (typeof saveState !== 'undefined') window.saveState = saveState;
        if (typeof loadState !== 'undefined') window.loadState = loadState;
        if (typeof switchTab !== 'undefined') window.switchTab = switchTab;
        if (typeof toggleTheme !== 'undefined') window.toggleTheme = toggleTheme;
        
        console.log('Functions made global:', {
            startScan: typeof window.startScan,
            showManualAdd: typeof window.showManualAdd
        });
    '''
    
    content = content[:insert_point] + window_assignments + '\n    ' + content[insert_point:]
    
    with open('index.html', 'w') as f:
        f.write(content)
    
    print("Added comprehensive window assignments")
else:
    print("Could not find script closing tag!")
