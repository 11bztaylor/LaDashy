#!/usr/bin/env python3

with open('index.html', 'r') as f:
    content = f.read()

# Make sure startScan is globally accessible
# Add it to window object after definition
import re

# Find where startScan is defined
scan_func_pattern = r'(async function startScan\(\) \{[^}]+\})'

def add_window_assignment(match):
    func = match.group(1)
    return func + '\n        window.startScan = startScan;'

content = re.sub(scan_func_pattern, add_window_assignment, content, flags=re.DOTALL)

# Do the same for other onclick functions
# showManualAdd
manual_pattern = r'(function showManualAdd\(\) \{[^}]+\})'
content = re.sub(manual_pattern, r'\1\n        window.showManualAdd = showManualAdd;', content, flags=re.DOTALL)

# Save
with open('index.html', 'w') as f:
    f.write(content)

print("Made functions globally accessible")
