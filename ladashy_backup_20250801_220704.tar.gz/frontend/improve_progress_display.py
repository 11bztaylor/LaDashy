#!/usr/bin/env python3

with open('frontend/index.html', 'r') as f:
    content = f.read()

# Update checkScanStatus to show better progress
import re

# Find and update the checkScanStatus function
old_pattern = r'(document\.getElementById\(\'progress-text\'\)\.textContent = status\.progress \|\| \'Scanning\.\.\.\';)'

new_code = '''document.getElementById('progress-text').textContent = status.progress || 'Scanning...';
                
                // Better progress calculation
                if (status.progress) {
                    console.log('Progress update:', status.progress);
                    
                    // Try to extract numbers from progress text
                    // Examples: "Scanning 254 hosts in 192.168.1.0/24", "Found open port 53 on 192.168.1.254"
                    if (status.progress.includes('Scanning') && status.progress.includes('hosts')) {
                        // Still scanning
                        document.getElementById('progress-fill').style.width = '50%';
                    } else if (status.progress.includes('Found open port')) {
                        // Finding services
                        document.getElementById('progress-fill').style.width = '75%';
                    } else if (status.progress.includes('complete')) {
                        // Done
                        document.getElementById('progress-fill').style.width = '100%';
                    }
                }'''

content = re.sub(old_pattern, new_code, content)

with open('frontend/index.html', 'w') as f:
    f.write(content)

print("Updated progress display logic")
