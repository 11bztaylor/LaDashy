#!/bin/bash

echo "Stopping existing servers..."
pkill -f "python backend/api.py"
pkill -f "python3 -m http.server"
sleep 2

echo "Starting LaDashy servers..."
cd /home/zach/homelab-documentation/ladashy_unified
source ../homelab-env/bin/activate

# Start API
python backend/api.py > api.log 2>&1 &
API_PID=$!
echo "API started with PID: $API_PID"

# Start frontend
cd frontend
python3 -m http.server 8080 > frontend.log 2>&1 &
FRONTEND_PID=$!
echo "Frontend started with PID: $FRONTEND_PID"

# Save PIDs for later
echo $API_PID > ../api.pid
echo $FRONTEND_PID > ../frontend.pid

sleep 2
echo ""
echo "Checking services..."
curl -s http://localhost:5000/api/health && echo " - API is running"
curl -s http://localhost:8080/ > /dev/null && echo " - Frontend is running"

echo ""
echo "LaDashy is ready at http://localhost:8080"
echo "Logs: api.log and frontend/frontend.log"
