#!/usr/bin/env python3
import re

# Read the HTML file
with open('frontend/index.html', 'r') as f:
    content = f.read()

# Extract script content
script_match = re.search(r'<script>(.*?)</script>', content, re.DOTALL)
if script_match:
    script_content = script_match.group(1)
    
    # Look for common JavaScript syntax errors
    print("Checking for syntax issues:")
    
    # Check for double backticks
    double_backticks = re.findall(r'``', script_content)
    if double_backticks:
        print(f"❌ Found {len(double_backticks)} double backticks - this will cause syntax errors!")
    else:
        print("✅ No double backticks found")
    
    # Check for template literal issues
    template_literals = re.findall(r'`[^`]*`', script_content)
    print(f"✅ Found {len(template_literals)} template literals")
    
    # Check if startScan is defined
    if 'async function startScan' in script_content:
        print("✅ startScan function is defined")
    else:
        print("❌ startScan function NOT found!")
        
    # Check quote balance
    for quote_type, quote_char in [("single", "'"), ("double", '"'), ("backtick", "`")]:
        count = script_content.count(quote_char)
        if count % 2 == 0:
            print(f"✅ {quote_type} quotes are balanced ({count})")
        else:
            print(f"❌ {quote_type} quotes are UNBALANCED ({count})")
