"""Documentation generators for LaDashy"""
