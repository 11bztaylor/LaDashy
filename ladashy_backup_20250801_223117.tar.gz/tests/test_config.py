# Test configuration for LaDashy
TEST_SERVICES = {
    "radarr": {
        "host": "192.168.100.4",
        "port": "7878",
        "api_key": "2f6a1fd0aeda49dca9226e740162fb49"
    },
    "plex": {
        "host": "192.168.1.100",
        "port": "32400",
        "token": "your-plex-token"
    }
}

API_BASE_URL = "http://localhost:5000"
